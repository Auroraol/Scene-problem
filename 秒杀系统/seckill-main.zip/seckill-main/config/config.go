package config

import (
	"encoding/json"
	"os"
	"sync"
	"time"
)

var (
	// 全局配置实例
	globalConfig *Config
	// 确保配置只被加载一次的锁
	configOnce sync.Once
)

// Config 系统配置结构
type Config struct {
	// 服务配置
	Service ServiceConfig `json:"service"`
	// MySQL配置
	MySQL MySQLConfig `json:"mysql"`
	// Redis配置
	Redis RedisConfig `json:"redis"`
	// RabbitMQ配置
	RabbitMQ RabbitMQConfig `json:"rabbitmq"`
}

// ServiceConfig 服务配置
type ServiceConfig struct {
	// 服务名称
	Name string `json:"name"`
	// 服务端口
	Port int `json:"port"`
	// 调试模式
	Debug bool `json:"debug"`
}

// MySQLConfig MySQL配置
type MySQLConfig struct {
	// 主机地址
	Host string `json:"host"`
	// 端口
	Port int `json:"port"`
	// 用户名
	Username string `json:"username"`
	// 密码
	Password string `json:"password"`
	// 数据库名
	Database string `json:"database"`
	// 连接参数
	Params string `json:"params"`
	// 最大空闲连接数
	MaxIdleConns int `json:"max_idle_conns"`
	// 最大打开连接数
	MaxOpenConns int `json:"max_open_conns"`
	// 连接最大生命周期
	ConnMaxLifetime time.Duration `json:"conn_max_lifetime"`
}

// RedisConfig Redis配置
type RedisConfig struct {
	// 主机地址
	Host string `json:"host"`
	// 端口
	Port int `json:"port"`
	// 密码
	Password string `json:"password"`
	// 数据库索引
	DB int `json:"db"`
	// 连接池大小
	PoolSize int `json:"pool_size"`
	// 最小空闲连接数
	MinIdleConns int `json:"min_idle_conns"`
	// 连接超时时间
	DialTimeout time.Duration `json:"dial_timeout"`
	// 读取超时时间
	ReadTimeout time.Duration `json:"read_timeout"`
	// 写入超时时间
	WriteTimeout time.Duration `json:"write_timeout"`
}

// RabbitMQConfig RabbitMQ配置
type RabbitMQConfig struct {
	// 主机地址
	Host string `json:"host"`
	// 端口
	Port int `json:"port"`
	// 用户名
	Username string `json:"username"`
	// 密码
	Password string `json:"password"`
	// 虚拟主机
	VHost string `json:"vhost"`
	// 订单队列名
	OrderQueue string `json:"order_queue"`
	// 死信队列名
	DeadLetterQueue string `json:"dead_letter_queue"`
	// 订单过期时间（秒）
	OrderExpiration int `json:"order_expiration"`
}

// GetConfig 获取全局配置实例
func GetConfig() *Config {
	configOnce.Do(func() {
		// 默认配置
		globalConfig = &Config{
			Service: ServiceConfig{
				Name:  "seckill",
				Port:  8080,
				Debug: true,
			},
			MySQL: MySQLConfig{
				Host:            "mysql",
				Port:            3306,
				Username:        "seckill",
				Password:        "seckill123",
				Database:        "seckill",
				Params:          "charset=utf8mb4&parseTime=True&loc=Local",
				MaxIdleConns:    10,
				MaxOpenConns:    100,
				ConnMaxLifetime: time.Hour,
			},
			Redis: RedisConfig{
				Host:         "redis",
				Port:         6379,
				Password:     "",
				DB:           0,
				PoolSize:     100,
				MinIdleConns: 10,
				DialTimeout:  5 * time.Second,
				ReadTimeout:  3 * time.Second,
				WriteTimeout: 3 * time.Second,
			},
			RabbitMQ: RabbitMQConfig{
				Host:            "rabbitmq",
				Port:            5672,
				Username:        "seckill",
				Password:        "seckill123",
				VHost:           "/",
				OrderQueue:      "seckill.order",
				DeadLetterQueue: "seckill.order.dead",
				OrderExpiration: 1800, // 30分钟
			},
		}

		// 尝试从配置文件加载
		loadConfigFromFile()
	})

	return globalConfig
}

// loadConfigFromFile 从配置文件加载配置
func loadConfigFromFile() {
	// 从环境变量获取配置文件路径，如果不存在则使用默认路径
	configFile := os.Getenv("CONFIG_FILE")
	if configFile == "" {
		configFile = "./config/config.json"
	}

	// 检查文件是否存在
	if _, err := os.Stat(configFile); os.IsNotExist(err) {
		// 配置文件不存在，使用默认配置
		return
	}

	// 读取配置文件
	data, err := os.ReadFile(configFile)
	if err != nil {
		return
	}

	// 解析配置文件
	var config Config
	if err := json.Unmarshal(data, &config); err != nil {
		return
	}

	// 更新全局配置
	globalConfig = &config
}