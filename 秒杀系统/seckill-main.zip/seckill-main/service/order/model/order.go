package model

import (
	"time"
)

// OrderStatus 订单状态枚举
type OrderStatus int

const (
	OrderStatusPending  OrderStatus = 0 // 待支付
	OrderStatusPaid     OrderStatus = 1 // 已支付
	OrderStatusCanceled OrderStatus = 2 // 已取消
)

// Order 订单模型
type Order struct {
	ID           int64       `json:"id" db:"id"`
	UserID       int64       `json:"user_id" db:"user_id"`
	ProductID    int64       `json:"product_id" db:"product_id"`
	ProductName  string      `json:"product_name" db:"product_name"`
	ProductPrice float64     `json:"product_price" db:"product_price"`
	Quantity     int         `json:"quantity" db:"quantity"`
	TotalAmount  float64     `json:"total_amount" db:"total_amount"`
	Status       OrderStatus `json:"status" db:"status"`
	PayTime      *time.Time  `json:"pay_time" db:"pay_time"`
	ExpireTime   *time.Time  `json:"expire_time" db:"expire_time"`
	CreatedAt    time.Time   `json:"created_at" db:"created_at"`
	UpdatedAt    time.Time   `json:"updated_at" db:"updated_at"`
}

// OrderCreateRequest 创建订单请求
type OrderCreateRequest struct {
	UserID    int64 `json:"user_id"`
	ProductID int64 `json:"product_id"`
	Quantity  int   `json:"quantity"`
}

// OrderPayRequest 支付订单请求
type OrderPayRequest struct {
	OrderID int64 `json:"order_id"`
	UserID  int64 `json:"user_id"`
}

// OrderCancelRequest 取消订单请求
type OrderCancelRequest struct {
	OrderID int64 `json:"order_id"`
	UserID  int64 `json:"user_id"`
}

// OrderQueryRequest 查询订单请求
type OrderQueryRequest struct {
	OrderID int64 `json:"order_id"`
	UserID  int64 `json:"user_id"`
}

// OrderInfo 订单信息（返回给前端）
type OrderInfo struct {
	Order
	StatusText string `json:"status_text"` // 状态文本
}

// GetStatusText 获取状态文本
func (o *Order) GetStatusText() string {
	switch o.Status {
	case OrderStatusPending:
		return "待支付"
	case OrderStatusPaid:
		return "已支付"
	case OrderStatusCanceled:
		return "已取消"
	default:
		return "未知状态"
	}
}

// ToOrderInfo 转换为订单信息
func (o *Order) ToOrderInfo() *OrderInfo {
	return &OrderInfo{
		Order:      *o,
		StatusText: o.GetStatusText(),
	}
}