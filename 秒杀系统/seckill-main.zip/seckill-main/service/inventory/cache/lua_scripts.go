package cache

// 库存相关的Lua脚本
const (
	// DecrInventoryScript 扣减库存的Lua脚本
	// KEYS[1]: 库存Hash键
	// ARGV[1]: 扣减数量
	DecrInventoryScript = `
		local key = KEYS[1]
		local count = tonumber(ARGV[1])
		
		local available = tonumber(redis.call('HGET', key, 'available'))
		if not available or available < count then
			return 0
		end
		
		redis.call('HINCRBY', key, 'available', -count)
		redis.call('HINCRBY', key, 'locked', count)
		redis.call('HINCRBY', key, 'version', 1)
		return 1
	`

	// UnlockInventoryScript 解锁库存的Lua脚本
	// KEYS[1]: 库存Hash键
	// ARGV[1]: 解锁数量
	UnlockInventoryScript = `
		local key = KEYS[1]
		local count = tonumber(ARGV[1])
		
		local locked = tonumber(redis.call('HGET', key, 'locked'))
		if not locked or locked < count then
			return 0
		end
		
		redis.call('HINCRBY', key, 'available', count)
		redis.call('HINCRBY', key, 'locked', -count)
		redis.call('HINCRBY', key, 'version', 1)
		return 1
	`

	// ConfirmDeductionScript 确认扣减的Lua脚本
	// KEYS[1]: 库存Hash键
	// ARGV[1]: 确认扣减数量
	ConfirmDeductionScript = `
		local key = KEYS[1]
		local count = tonumber(ARGV[1])
		
		local locked = tonumber(redis.call('HGET', key, 'locked'))
		if not locked or locked < count then
			return 0
		end
		
		redis.call('HINCRBY', key, 'locked', -count)
		redis.call('HINCRBY', key, 'version', 1)
		return 1
	`

	// ReleaseLockScript 释放分布式锁的Lua脚本
	// KEYS[1]: 锁键
	// ARGV[1]: 锁值
	ReleaseLockScript = `
		if redis.call('GET', KEYS[1]) == ARGV[1] then
			return redis.call('DEL', KEYS[1])
		else
			return 0
		end
	`
)
