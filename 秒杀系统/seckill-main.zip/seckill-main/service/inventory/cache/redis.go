package cache

import (
	"context"
	"errors"
	"fmt"
	"strconv"
	"time"

	"github.com/ammyhaber/seckill/service/inventory/model"
	"github.com/go-redis/redis/v8"
	"github.com/google/uuid"
)

const (
	// 库存Hash前缀
	InventoryHashPrefix = "seckill:inventory:"
	// 库存锁前缀
	InventoryLockPrefix = "seckill:inventory:lock:"
	// 锁超时时间
	LockExpiration = 10 * time.Second
)

type RedisCache struct {
	client *redis.Client
}

func NewRedisCache(client *redis.Client) *RedisCache {
	return &RedisCache{client: client}
}

// WarmUpInventory 库存预热，将MySQL中的库存数据加载到Redis
func (c *RedisCache) WarmUpInventory(ctx context.Context, inventories []*model.Inventory) error {
	pipe := c.client.Pipeline()
	for _, inv := range inventories {
		key := fmt.Sprintf("%s%d", InventoryHashPrefix, inv.ProductID)
		// 使用Hash结构存储库存信息
		pipe.HSet(ctx, key, map[string]interface{}{
			"product_id": inv.ProductID,
			"total":      inv.Total,
			"available":  inv.Available,
			"locked":     inv.Locked,
			"version":    inv.Version,
		})
	}
	_, err := pipe.Exec(ctx)
	return err
}

// GetInventory 从Redis获取库存信息
func (c *RedisCache) GetInventory(ctx context.Context, productID int64) (*model.Inventory, error) {
	key := fmt.Sprintf("%s%d", InventoryHashPrefix, productID)
	values, err := c.client.HGetAll(ctx, key).Result()
	if err != nil {
		return nil, err
	}

	// 如果不存在则返回nil
	if len(values) == 0 {
		return nil, errors.New("库存不存在")
	}

	available, _ := strconv.Atoi(values["available"])
	locked, _ := strconv.Atoi(values["locked"])
	version, _ := strconv.Atoi(values["version"])

	return &model.Inventory{
		ProductID: productID,
		Available: available,
		Locked:    locked,
		Version:   version,
	}, nil
}

// DecrInventory 使用Lua脚本原子性扣减库存
func (c *RedisCache) DecrInventory(ctx context.Context, productID int64, count int) (bool, error) {
	key := fmt.Sprintf("%s%d", InventoryHashPrefix, productID)
	result, err := c.client.Eval(ctx, DecrInventoryScript, []string{key}, count).Result()
	if err != nil {
		return false, err
	}

	return result.(int64) == 1, nil
}

// UnlockInventory 解锁库存
func (c *RedisCache) UnlockInventory(ctx context.Context, productID int64, count int) error {
	key := fmt.Sprintf("%s%d", InventoryHashPrefix, productID)
	result, err := c.client.Eval(ctx, UnlockInventoryScript, []string{key}, count).Result()
	if err != nil {
		return err
	}

	if result.(int64) == 0 {
		return errors.New("解锁库存失败，锁定库存不足")
	}
	return nil
}

// ConfirmDeduction 确认扣减库存
func (c *RedisCache) ConfirmDeduction(ctx context.Context, productID int64, count int) error {
	key := fmt.Sprintf("%s%d", InventoryHashPrefix, productID)
	result, err := c.client.Eval(ctx, ConfirmDeductionScript, []string{key}, count).Result()
	if err != nil {
		return err
	}

	if result.(int64) == 0 {
		return errors.New("确认扣减失败，锁定库存不足")
	}
	return nil
}

// AcquireLock 获取分布式锁
func (c *RedisCache) AcquireLock(ctx context.Context, productID int64) (string, error) {
	lockKey := fmt.Sprintf("%s%d", InventoryLockPrefix, productID)
	lockValue := uuid.New().String()

	success, err := c.client.SetNX(ctx, lockKey, lockValue, LockExpiration).Result()
	if err != nil {
		return "", err
	}
	if !success {
		return "", errors.New("获取锁失败")
	}

	return lockValue, nil
}

// ReleaseLock 释放分布式锁
func (c *RedisCache) ReleaseLock(ctx context.Context, productID int64, lockValue string) bool {
	lockKey := fmt.Sprintf("%s%d", InventoryLockPrefix, productID)

	// 使用Lua脚本确保原子性释放锁
	result, err := c.client.Eval(ctx, ReleaseLockScript, []string{lockKey}, lockValue).Result()
	if err != nil || result.(int64) == 0 {
		return false
	}
	return true
}

// SetInventory 设置库存信息
func (c *RedisCache) SetInventory(ctx context.Context, inventory *model.Inventory) error {
	if inventory == nil {
		return errors.New("库存信息为空")
	}

	key := fmt.Sprintf("%s%d", InventoryHashPrefix, inventory.ProductID)
	_, err := c.client.HMSet(ctx, key, map[string]interface{}{
		"available": inventory.Available,
		"locked":    inventory.Locked,
		"version":   inventory.Version,
	}).Result()

	return err
}
