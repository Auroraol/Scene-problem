package model

import (
	"time"
)

// LockStatus 表示库存锁定状态
type LockStatus int

const (
	// LockStatusLocked 已锁定
	LockStatusLocked LockStatus = iota + 1
	// LockStatusConfirmed 已确认扣减
	LockStatusConfirmed
	// LockStatusCanceled 已取消
	LockStatusCanceled
)

// InventoryLock 库存锁定记录模型
type InventoryLock struct {
	ID          int64      `json:"id" db:"id"`
	OrderID     string     `json:"order_id" db:"order_id"`
	ProductID   int64      `json:"product_id" db:"product_id"`
	Count       int        `json:"count" db:"count"`
	Status      LockStatus `json:"status" db:"status"`
	LockTime    time.Time  `json:"lock_time" db:"lock_time"`
	ConfirmTime *time.Time `json:"confirm_time" db:"confirm_time"`
	CancelTime  *time.Time `json:"cancel_time" db:"cancel_time"`
	CreatedAt   time.Time  `json:"created_at" db:"created_at"`
	UpdatedAt   time.Time  `json:"updated_at" db:"updated_at"`
}

// InventoryLockRequest 锁定库存请求
type InventoryLockRequest struct {
	OrderID   string `json:"order_id"`
	ProductID int64  `json:"product_id"`
	Count     int    `json:"count"`
}

// InventoryLockConfirmRequest 确认库存扣减请求
type InventoryLockConfirmRequest struct {
	OrderID   string `json:"order_id"`
	ProductID int64  `json:"product_id"`
	Count     int    `json:"count"` // 可选，用于验证
}

// InventoryLockCancelRequest 取消库存锁定请求
type InventoryLockCancelRequest struct {
	OrderID   string `json:"order_id"`
	ProductID int64  `json:"product_id"`
	Count     int    `json:"count"` // 可选，用于验证
}
