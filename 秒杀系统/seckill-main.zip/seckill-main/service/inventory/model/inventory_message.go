package model

import (
	"time"
)

// MessageType 消息类型
type MessageType string

const (
	// MessageTypeLockInventory 锁定库存消息
	MessageTypeLockInventory MessageType = "LOCK_INVENTORY"
	// MessageTypeConfirmInventory 确认库存消息
	MessageTypeConfirmInventory MessageType = "CONFIRM_INVENTORY"
	// MessageTypeCancelInventory 取消库存消息
	MessageTypeCancelInventory MessageType = "CANCEL_INVENTORY"
)

// InventoryMessage 库存消息
type InventoryMessage struct {
	MessageID   string      `json:"message_id"`   // 消息ID
	MessageType MessageType `json:"message_type"` // 消息类型
	OrderID     string      `json:"order_id"`     // 订单ID
	ProductID   int64       `json:"product_id"`   // 商品ID
	Count       int         `json:"count"`        // 数量
	UserID      int64       `json:"user_id"`      // 用户ID
	CreateTime  time.Time   `json:"create_time"`  // 创建时间
}

// NewLockInventoryMessage 创建锁定库存消息
func NewLockInventoryMessage(messageID, orderID string, productID int64, count int, userID int64) *InventoryMessage {
	return &InventoryMessage{
		MessageID:   messageID,
		MessageType: MessageTypeLockInventory,
		OrderID:     orderID,
		ProductID:   productID,
		Count:       count,
		UserID:      userID,
		CreateTime:  time.Now(),
	}
}

// NewConfirmInventoryMessage 创建确认库存消息
func NewConfirmInventoryMessage(messageID, orderID string, productID int64, count int, userID int64) *InventoryMessage {
	return &InventoryMessage{
		MessageID:   messageID,
		MessageType: MessageTypeConfirmInventory,
		OrderID:     orderID,
		ProductID:   productID,
		Count:       count,
		UserID:      userID,
		CreateTime:  time.Now(),
	}
}

// NewCancelInventoryMessage 创建取消库存消息
func NewCancelInventoryMessage(messageID, orderID string, productID int64, count int, userID int64) *InventoryMessage {
	return &InventoryMessage{
		MessageID:   messageID,
		MessageType: MessageTypeCancelInventory,
		OrderID:     orderID,
		ProductID:   productID,
		Count:       count,
		UserID:      userID,
		CreateTime:  time.Now(),
	}
}
