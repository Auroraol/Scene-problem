package model

import (
	"time"
)

// Inventory 库存模型
type Inventory struct {
	ID         int64     `json:"id" db:"id"`
	ProductID  int64     `json:"product_id" db:"product_id"`
	Total      int       `json:"total" db:"total"`
	Available  int       `json:"available" db:"available"`
	Locked     int       `json:"locked" db:"locked"`
	Version    int       `json:"version" db:"version"`
	CreatedAt  time.Time `json:"created_at" db:"created_at"`
	UpdatedAt  time.Time `json:"updated_at" db:"updated_at"`
}

// Product 商品模型
type Product struct {
	ID          int64     `json:"id" db:"id"`
	Name        string    `json:"name" db:"name"`
	Description string    `json:"description" db:"description"`
	Price       float64   `json:"price" db:"price"`
	Stock       int       `json:"stock" db:"stock"`
	Status      int       `json:"status" db:"status"`
	CreatedAt   time.Time `json:"created_at" db:"created_at"`
	UpdatedAt   time.Time `json:"updated_at" db:"updated_at"`
}

// InventoryDetail 库存详情（包含商品信息）
type InventoryDetail struct {
	Inventory
	ProductName  string  `json:"product_name" db:"product_name"`
	ProductPrice float64 `json:"product_price" db:"product_price"`
}