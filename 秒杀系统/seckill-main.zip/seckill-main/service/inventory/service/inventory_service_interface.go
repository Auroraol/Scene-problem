package service

import (
	"context"

	"github.com/ammyhaber/seckill/service/inventory/model"
)

// InventoryServiceInterface 定义库存服务接口
type InventoryServiceInterface interface {
	// InitCache 初始化缓存
	InitCache(ctx context.Context) error

	// GetInventoryDetail 获取库存详情
	GetInventoryDetail(ctx context.Context, productID int64) (*model.InventoryDetail, error)

	// DecrInventory 扣减库存
	DecrInventory(ctx context.Context, productID int64, count int) (bool, error)

	// ConfirmDeduction 确认扣减
	ConfirmDeduction(ctx context.Context, productID int64, count int) error

	// CancelDeduction 取消扣减
	CancelDeduction(ctx context.Context, productID int64, count int) error
}
