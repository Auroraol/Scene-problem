package service

import (
	"context"
	"time"

	"github.com/ammyhaber/seckill/service/inventory/model"
)

// InventoryLockServiceInterface 定义库存锁定服务接口
type InventoryLockServiceInterface interface {
	// LockInventory 锁定库存（第一阶段预扣减）
	LockInventory(ctx context.Context, req *model.InventoryLockRequest) (bool, error)

	// ConfirmInventoryDeduction 确认库存扣减（第二阶段确认扣减）
	ConfirmInventoryDeduction(ctx context.Context, req *model.InventoryLockConfirmRequest) error

	// CancelInventoryDeduction 取消库存扣减（回滚操作）
	CancelInventoryDeduction(ctx context.Context, req *model.InventoryLockCancelRequest) error

	// GetInventoryLockDetail 获取库存锁定详情
	GetInventoryLockDetail(ctx context.Context, orderID string, productID int64) (*model.InventoryLock, error)

	// ProcessExpiredLocks 处理过期的锁
	ProcessExpiredLocks(ctx context.Context, expireDuration time.Duration) error
}
