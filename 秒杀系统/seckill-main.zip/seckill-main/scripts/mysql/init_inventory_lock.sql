-- 创建库存锁定表
CREATE TABLE IF NOT EXISTS `inventory_lock` (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT '主键ID',
  `order_id` varchar(64) NOT NULL COMMENT '订单ID',
  `product_id` bigint NOT NULL COMMENT '商品ID',
  `count` int NOT NULL COMMENT '锁定数量',
  `status` tinyint NOT NULL DEFAULT '1' COMMENT '状态: 1-锁定, 2-已确认, 3-已取消',
  `lock_time` datetime NOT NULL COMMENT '锁定时间',
  `confirm_time` datetime DEFAULT NULL COMMENT '确认时间',
  `cancel_time` datetime DEFAULT NULL COMMENT '取消时间',
  `created_at` datetime NOT NULL COMMENT '创建时间',
  `updated_at` datetime NOT NULL COMMENT '更新时间',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_order_product` (`order_id`,`product_id`),
  KEY `idx_product_status` (`product_id`,`status`),
  KEY `idx_lock_time` (`status`,`lock_time`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='库存锁定记录';

-- 添加索引以提高查询性能
ALTER TABLE `inventory` ADD INDEX IF NOT EXISTS `idx_product_id` (`product_id`);

-- 添加数据表关联
ALTER TABLE `inventory_lock` 
ADD CONSTRAINT `fk_inventory_lock_product` FOREIGN KEY (`product_id`) REFERENCES `inventory` (`product_id`) ON DELETE CASCADE; 