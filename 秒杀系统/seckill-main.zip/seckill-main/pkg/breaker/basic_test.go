package breaker

import (
	"testing"
	"time"
)

func TestBasicBreaker(t *testing.T) {
	// 这是一个快速测试，不需要等待
	// 设置测试超时
	t.Parallel()
	timeout := time.AfterFunc(5*time.Second, func() {
		t.Error("测试超时")
		t.FailNow()
	})
	defer timeout.Stop()

	breaker := NewAdaptiveBreaker(
		WithErrorThreshold(0.5),
		WithMinRequestCount(5),
	)

	// 检查初始状态
	if state := breaker.GetState(); state != StateClosed {
		t.Errorf("预期初始状态为关闭，但得到: %d", state)
	}

	// 测试重置功能
	breaker.Reset()
	if state := breaker.GetState(); state != StateClosed {
		t.Errorf("重置后预期状态为关闭，但得到: %d", state)
	}

	// 测试降级函数注册
	breaker.RegisterFallback("test", func(err error) (interface{}, error) {
		return "降级结果", nil
	})

	// 测试通过
	t.Log("基本功能测试通过")
}
