package breaker

// BreakerExecutor 熔断器执行器接口
type BreakerExecutor interface {
	Execute(fn func() error) error
	GetState() int
	Reset()
}
