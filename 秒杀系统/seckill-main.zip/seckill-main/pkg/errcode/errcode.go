package errcode

// 系统级错误码
const (
	Success          = 0
	ServerError      = 10000
	InvalidParams    = 10001
	Unauthorized     = 10002
	TooManyRequests  = 10003
	NotFound         = 10004
)

// 业务错误码 - 库存服务 (2xxxx)
const (
	InventoryNotEnough = 20001
	InventoryDecrFail  = 20002
	ProductNotExist    = 20003
)

// 业务错误码 - 订单服务 (3xxxx)
const (
	OrderCreateFail    = 30001
	OrderNotExist      = 30002
	OrderStatusInvalid = 30003
	OrderExpired       = 30004
)

// 错误码与错误信息映射
var MsgMap = map[int]string{
	Success:          "成功",
	ServerError:      "服务内部错误",
	InvalidParams:    "参数错误",
	Unauthorized:     "未授权",
	TooManyRequests:  "请求过于频繁",
	NotFound:         "资源不存在",
	
	InventoryNotEnough: "库存不足",
	InventoryDecrFail:  "扣减库存失败",
	ProductNotExist:    "商品不存在",
	
	OrderCreateFail:    "创建订单失败",
	OrderNotExist:      "订单不存在",
	OrderStatusInvalid: "订单状态不正确",
	OrderExpired:       "订单已过期",
}

// GetMsg 获取错误信息
func GetMsg(code int) string {
	msg, ok := MsgMap[code]
	if ok {
		return msg
	}
	return MsgMap[ServerError]
}