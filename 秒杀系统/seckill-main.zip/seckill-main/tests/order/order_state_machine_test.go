package order

import (
	"context"
	"fmt"
	"os"
	"path/filepath"
	"testing"
	"time"

	"github.com/ammyhaber/seckill/config"
	invCache "github.com/ammyhaber/seckill/service/inventory/cache"
	invDao "github.com/ammyhaber/seckill/service/inventory/dao"
	invService "github.com/ammyhaber/seckill/service/inventory/service"
	"github.com/ammyhaber/seckill/service/order/dao"
	orderModel "github.com/ammyhaber/seckill/service/order/model"
	"github.com/ammyhaber/seckill/service/order/service"
	"github.com/go-redis/redis/v8"
	_ "github.com/go-sql-driver/mysql"
	"github.com/jmoiron/sqlx"
)

var (
	testDB                   *sqlx.DB
	testRedisClient          *redis.Client
	testOrderDAO             *dao.OrderDAO
	testOrderService         *service.OrderService
	testInventoryService     invService.InventoryServiceInterface
	testInventoryLockService invService.InventoryLockServiceInterface
)

// 初始化测试环境
func setupOrderStateTest() {
	// 如果已经初始化过，就不要重复初始化
	if testDB != nil && testOrderService != nil {
		return
	}

	// 获取当前工作目录
	workDir, err := os.Getwd()
	if err != nil {
		fmt.Printf("获取当前工作目录失败: %v\n", err)
		return
	}

	// 设置配置文件路径 - 确保使用绝对路径
	configPath := filepath.Join(workDir, "..", "config", "config_test.json")
	if _, err := os.Stat(configPath); os.IsNotExist(err) {
		// 尝试替代路径
		configPath = filepath.Join(workDir, "..", "..", "config", "config_test.json")
		if _, err := os.Stat(configPath); os.IsNotExist(err) {
			fmt.Printf("找不到测试配置文件: %v\n", err)
			return
		}
	}

	fmt.Printf("使用配置文件: %s\n", configPath)
	os.Setenv("CONFIG_FILE", configPath)

	// 获取配置
	cfg := config.GetConfig()

	// 检查并修正MySQL主机配置
	if cfg.MySQL.Host == "mysql" {
		fmt.Printf("修正MySQL主机从 %s 为 localhost\n", cfg.MySQL.Host)
		cfg.MySQL.Host = "localhost"
	}

	// 初始化数据库连接
	dsn := fmt.Sprintf("%s:%s@tcp(%s:%d)/%s?%s",
		cfg.MySQL.Username,
		cfg.MySQL.Password,
		cfg.MySQL.Host,
		cfg.MySQL.Port,
		cfg.MySQL.Database,
		cfg.MySQL.Params)

	fmt.Printf("数据库连接DSN: %s:%s@tcp(%s:%d)/%s?%s\n",
		cfg.MySQL.Username,
		"******", // 隐藏密码
		cfg.MySQL.Host,
		cfg.MySQL.Port,
		cfg.MySQL.Database,
		cfg.MySQL.Params)

	testDB, err = sqlx.Connect("mysql", dsn)
	if err != nil {
		fmt.Printf("连接数据库失败: %v\n", err)
		return
	}

	// 设置连接池参数
	testDB.SetMaxIdleConns(cfg.MySQL.MaxIdleConns)
	testDB.SetMaxOpenConns(cfg.MySQL.MaxOpenConns)
	testDB.SetConnMaxLifetime(cfg.MySQL.ConnMaxLifetime)

	// 确保必要的表存在
	ensureTestTablesExist()

	// 初始化Redis客户端
	testRedisClient = redis.NewClient(&redis.Options{
		Addr:         fmt.Sprintf("%s:%d", cfg.Redis.Host, cfg.Redis.Port),
		Password:     cfg.Redis.Password,
		DB:           cfg.Redis.DB,
		PoolSize:     cfg.Redis.PoolSize,
		MinIdleConns: cfg.Redis.MinIdleConns,
		DialTimeout:  cfg.Redis.DialTimeout,
		ReadTimeout:  cfg.Redis.ReadTimeout,
		WriteTimeout: cfg.Redis.WriteTimeout,
	})

	// 初始化库存服务相关组件
	inventoryDAO := invDao.NewInventoryDAO(testDB)
	inventoryLockDAO := invDao.NewInventoryLockDAO(testDB)
	inventoryCache := invCache.NewRedisCache(testRedisClient)
	testInventoryService = invService.NewInventoryService(inventoryDAO, inventoryCache)
	testInventoryLockService = invService.NewInventoryLockService(inventoryDAO, inventoryLockDAO, inventoryCache)

	// 初始化订单服务
	testOrderDAO = dao.NewOrderDAO(testDB)

	// RabbitMQ可以为nil，测试环境不需要实际发送消息
	// 设置库存服务地址为空串，将直接使用注入的实例
	testOrderService = service.NewOrderService(testOrderDAO, testRedisClient, nil, "")

	// 设置实际的库存服务
	testOrderService.SetInventoryService(testInventoryService)

	// 初始化库存缓存
	ctx := context.Background()
	// 清理可能存在的旧数据
	testRedisClient.FlushDB(ctx)

	// 初始化缓存
	err = testInventoryService.InitCache(ctx)
	if err != nil {
		fmt.Printf("初始化缓存失败: %v\n", err)
	}

	// 准备测试数据
	prepareOrderTestData()
}

// 清理测试环境
func teardownOrderStateTest() {
	// 只清理测试数据，不关闭连接
	cleanupOrderTestData()
}

// 准备订单测试数据
func prepareOrderTestData() {
	// 清理旧数据
	cleanupOrderTestData()

	// 创建测试用户
	testDB.MustExec("INSERT INTO user (id, username, password, email, status) VALUES (3001, 'testuser', 'password', 'test@example.com', 1)")

	// 创建测试商品
	testDB.MustExec("INSERT INTO product (id, name, description, price, stock, status) VALUES (3001, '状态机测试商品', '测试商品描述', 100.00, 1000, 1)")

	// 创建测试库存
	testDB.MustExec("INSERT INTO inventory (product_id, total, available, locked, version) VALUES (3001, 1000, 1000, 0, 0)")
}

// 清理订单测试数据
func cleanupOrderTestData() {
	// 删除测试订单
	for i := 0; i < 8; i++ {
		testDB.MustExec(fmt.Sprintf("DELETE FROM order_%d WHERE user_id = 3001", i))
	}

	// 删除测试用户、商品和库存
	testDB.MustExec("DELETE FROM user WHERE id = 3001")
	testDB.MustExec("DELETE FROM product WHERE id = 3001")
	testDB.MustExec("DELETE FROM inventory WHERE product_id = 3001")
}

// 确保测试所需的表存在
func ensureTestTablesExist() {
	// 用户表
	testDB.MustExec(`
		CREATE TABLE IF NOT EXISTS user (
			id bigint(20) NOT NULL AUTO_INCREMENT COMMENT '用户ID',
			username varchar(64) NOT NULL COMMENT '用户名',
			password varchar(128) NOT NULL COMMENT '密码',
			email varchar(128) DEFAULT NULL COMMENT '邮箱',
			status tinyint(4) NOT NULL DEFAULT '1' COMMENT '状态：0-禁用，1-正常',
			created_at timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
			updated_at timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
			PRIMARY KEY (id),
			UNIQUE KEY uk_username (username),
			KEY idx_status (status)
		) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='用户表'
	`)

	// 商品表
	testDB.MustExec(`
		CREATE TABLE IF NOT EXISTS product (
			id bigint(20) NOT NULL AUTO_INCREMENT COMMENT '商品ID',
			name varchar(255) NOT NULL COMMENT '商品名称',
			description text COMMENT '商品描述',
			price decimal(10,2) NOT NULL COMMENT '商品价格',
			stock int(11) NOT NULL COMMENT '商品库存',
			status tinyint(4) NOT NULL DEFAULT '1' COMMENT '状态：0-下架，1-上架',
			created_at timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
			updated_at timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
			PRIMARY KEY (id),
			KEY idx_status (status)
		) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='商品表'
	`)

	// 库存表
	testDB.MustExec(`
		CREATE TABLE IF NOT EXISTS inventory (
			id bigint(20) NOT NULL AUTO_INCREMENT COMMENT 'ID',
			product_id bigint(20) NOT NULL COMMENT '商品ID',
			total int(11) NOT NULL COMMENT '总库存',
			available int(11) NOT NULL COMMENT '可用库存',
			locked int(11) NOT NULL DEFAULT '0' COMMENT '锁定库存',
			version int(11) NOT NULL DEFAULT '0' COMMENT '版本号，用于乐观锁',
			created_at timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
			updated_at timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
			PRIMARY KEY (id),
			UNIQUE KEY uk_product_id (product_id)
		) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='库存表'
	`)

	// 订单表（按用户ID哈希分表，这里创建8个分表）
	for i := 0; i < 8; i++ {
		testDB.MustExec(fmt.Sprintf(`
			CREATE TABLE IF NOT EXISTS order_%d (
				id bigint(20) NOT NULL COMMENT '订单ID',
				user_id bigint(20) NOT NULL COMMENT '用户ID',
				product_id bigint(20) NOT NULL COMMENT '商品ID',
				product_name varchar(255) NOT NULL COMMENT '商品名称',
				product_price decimal(10,2) NOT NULL COMMENT '商品价格',
				quantity int(11) NOT NULL COMMENT '购买数量',
				total_amount decimal(10,2) NOT NULL COMMENT '订单总金额',
				status tinyint(4) NOT NULL DEFAULT '0' COMMENT '订单状态：0-待支付，1-已支付，2-已取消',
				pay_time timestamp NULL DEFAULT NULL COMMENT '支付时间',
				expire_time timestamp NULL DEFAULT NULL COMMENT '过期时间',
				created_at timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
				updated_at timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
				PRIMARY KEY (id),
				KEY idx_user_id (user_id),
				KEY idx_status (status)
			) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='订单表%d'
		`, i, i))
	}
}

// TestOrderStateMachine 测试订单状态机
func TestOrderStateMachine(t *testing.T) {
	// 跳过测试如果无法连接数据库
	if testDB == nil {
		setupOrderStateTest()
		if testDB == nil {
			t.Skip("无法连接到数据库，跳过订单状态机测试")
		}
		// 不在这里调用defer teardownOrderStateTest()，保持连接
	}

	// 清理之前的测试数据
	cleanupOrderTestData()
	// 准备新的测试数据
	prepareOrderTestData()

	// 测试数据
	userID := int64(3001)
	productID := int64(3001)
	quantity := 1

	// 创建上下文
	ctx := context.Background()

	// 1. 创建订单（初始状态：待支付）
	orderReq := &orderModel.OrderCreateRequest{
		UserID:    userID,
		ProductID: productID,
		Quantity:  quantity,
	}

	orderInfo, err := testOrderService.CreateOrder(ctx, orderReq)
	if err != nil {
		t.Fatalf("创建订单失败: %v", err)
	}

	// 验证订单初始状态为待支付
	if orderInfo.Status != orderModel.OrderStatusPending {
		t.Errorf("订单初始状态错误, 期望: %d, 实际: %d", orderModel.OrderStatusPending, orderInfo.Status)
	}

	t.Logf("订单创建成功, ID: %d, 状态: %s", orderInfo.ID, orderInfo.StatusText)

	// 2. 支付订单（状态转换：待支付 -> 已支付）
	payReq := &orderModel.OrderPayRequest{
		OrderID: orderInfo.ID,
		UserID:  userID,
	}

	err = testOrderService.PayOrder(ctx, payReq)
	if err != nil {
		t.Fatalf("支付订单失败: %v", err)
	}

	// 查询订单状态
	queryReq := &orderModel.OrderQueryRequest{
		OrderID: orderInfo.ID,
		UserID:  userID,
	}
	orderInfo, err = testOrderService.GetOrderByID(ctx, queryReq)
	if err != nil {
		t.Fatalf("查询订单失败: %v", err)
	}

	// 验证订单状态已更新为已支付
	if orderInfo.Status != orderModel.OrderStatusPaid {
		t.Errorf("订单支付后状态错误, 期望: %d, 实际: %d", orderModel.OrderStatusPaid, orderInfo.Status)
	}

	t.Logf("订单支付成功, ID: %d, 状态: %s", orderInfo.ID, orderInfo.StatusText)

	// 3. 测试非法状态转换（已支付 -> 已取消，应该失败）
	cancelReq := &orderModel.OrderCancelRequest{
		OrderID: orderInfo.ID,
		UserID:  userID,
	}

	err = testOrderService.CancelOrder(ctx, cancelReq)
	if err == nil {
		t.Error("取消已支付订单应该失败，但成功了")
	} else {
		t.Logf("期望的错误: %v", err)
	}

	// 4. 创建新订单测试取消流程
	orderReq2 := &orderModel.OrderCreateRequest{
		UserID:    userID,
		ProductID: productID,
		Quantity:  quantity,
	}

	orderInfo2, err := testOrderService.CreateOrder(ctx, orderReq2)
	if err != nil {
		t.Fatalf("创建第二个订单失败: %v", err)
	}

	// 验证订单初始状态为待支付
	if orderInfo2.Status != orderModel.OrderStatusPending {
		t.Errorf("订单初始状态错误, 期望: %d, 实际: %d", orderModel.OrderStatusPending, orderInfo2.Status)
	}

	// 5. 取消订单（状态转换：待支付 -> 已取消）
	cancelReq2 := &orderModel.OrderCancelRequest{
		OrderID: orderInfo2.ID,
		UserID:  userID,
	}

	err = testOrderService.CancelOrder(ctx, cancelReq2)
	if err != nil {
		t.Fatalf("取消订单失败: %v", err)
	}

	// 查询订单状态
	queryReq2 := &orderModel.OrderQueryRequest{
		OrderID: orderInfo2.ID,
		UserID:  userID,
	}
	orderInfo2, err = testOrderService.GetOrderByID(ctx, queryReq2)
	if err != nil {
		t.Fatalf("查询订单失败: %v", err)
	}

	// 验证订单状态已更新为已取消
	if orderInfo2.Status != orderModel.OrderStatusCanceled {
		t.Errorf("订单取消后状态错误, 期望: %d, 实际: %d", orderModel.OrderStatusCanceled, orderInfo2.Status)
	}

	t.Logf("订单取消成功, ID: %d, 状态: %s", orderInfo2.ID, orderInfo2.StatusText)

	// 6. 测试非法状态转换（已取消 -> 已支付，应该失败）
	payReq2 := &orderModel.OrderPayRequest{
		OrderID: orderInfo2.ID,
		UserID:  userID,
	}

	err = testOrderService.PayOrder(ctx, payReq2)
	if err == nil {
		t.Error("支付已取消订单应该失败，但成功了")
	} else {
		t.Logf("期望的错误: %v", err)
	}
}

// TestOrderExpiration 测试订单过期功能
func TestOrderExpiration(t *testing.T) {
	// 跳过测试如果无法连接数据库
	if testDB == nil {
		setupOrderStateTest()
		if testDB == nil {
			t.Skip("无法连接到数据库，跳过订单过期测试")
		}
		// 不在这里调用defer teardownOrderStateTest()，保持连接
	}

	// 清理之前的测试数据
	cleanupOrderTestData()
	// 准备新的测试数据
	prepareOrderTestData()

	// 测试数据
	userID := int64(3001)
	productID := int64(3001)
	quantity := 1

	// 创建上下文
	ctx := context.Background()

	// 1. 创建订单，设置非常短的过期时间（2秒）
	orderReq := &orderModel.OrderCreateRequest{
		UserID:    userID,
		ProductID: productID,
		Quantity:  quantity,
	}

	orderInfo, err := testOrderService.CreateOrder(ctx, orderReq)
	if err != nil {
		t.Fatalf("创建订单失败: %v", err)
	}

	// 获取订单ID
	orderID := orderInfo.ID

	// 手动更新过期时间为当前时间前1分钟（模拟已过期）
	expireTime := time.Now().Add(-1 * time.Minute)
	tableName := fmt.Sprintf("order_%d", userID%8)
	_, err = testDB.Exec(fmt.Sprintf("UPDATE %s SET expire_time = ? WHERE id = ?", tableName), expireTime, orderID)
	if err != nil {
		t.Fatalf("更新订单过期时间失败: %v", err)
	}

	// 2. 模拟系统扫描过期订单的过程
	expiredOrders, err := testOrderDAO.GetExpiredOrders()
	if err != nil {
		t.Fatalf("获取过期订单失败: %v", err)
	}

	// 验证我们的测试订单在过期列表中
	foundExpired := false
	for _, order := range expiredOrders {
		if order.ID == orderID {
			foundExpired = true
			break
		}
	}

	if !foundExpired {
		t.Fatalf("过期订单列表中未找到测试订单")
	}

	// 3. 处理过期订单（系统通常会通过消息队列完成）
	// 这里我们直接调用取消订单的方法
	cancelReq := &orderModel.OrderCancelRequest{
		OrderID: orderID,
		UserID:  userID,
	}

	err = testOrderService.CancelOrder(ctx, cancelReq)
	if err != nil {
		t.Fatalf("取消过期订单失败: %v", err)
	}

	// 4. 查询订单状态
	queryReq := &orderModel.OrderQueryRequest{
		OrderID: orderID,
		UserID:  userID,
	}
	orderInfo, err = testOrderService.GetOrderByID(ctx, queryReq)
	if err != nil {
		t.Fatalf("查询订单失败: %v", err)
	}

	// 验证订单状态已更新为已取消
	if orderInfo.Status != orderModel.OrderStatusCanceled {
		t.Errorf("过期订单处理后状态错误, 期望: %d, 实际: %d", orderModel.OrderStatusCanceled, orderInfo.Status)
	}

	t.Logf("过期订单处理成功, ID: %d, 状态: %s", orderID, orderInfo.StatusText)
}

// TestIllegalStateTransitions 测试非法状态转换
func TestIllegalStateTransitions(t *testing.T) {
	// 跳过测试如果无法连接数据库
	if testDB == nil {
		setupOrderStateTest()
		if testDB == nil {
			t.Skip("无法连接到数据库，跳过非法状态转换测试")
		}
		// 不在这里调用defer teardownOrderStateTest()，保持连接
	}

	// 清理之前的测试数据
	cleanupOrderTestData()
	// 准备新的测试数据
	prepareOrderTestData()

	// 测试数据
	userID := int64(3001)
	productID := int64(3001)
	quantity := 1

	// 创建上下文
	ctx := context.Background()

	// 创建订单
	orderReq := &orderModel.OrderCreateRequest{
		UserID:    userID,
		ProductID: productID,
		Quantity:  quantity,
	}

	orderInfo, err := testOrderService.CreateOrder(ctx, orderReq)
	if err != nil {
		t.Fatalf("创建订单失败: %v", err)
	}

	orderID := orderInfo.ID

	// 测试非法状态转换：直接在数据库中将订单状态设为已支付
	tableName := fmt.Sprintf("order_%d", userID%8)
	_, err = testDB.Exec(fmt.Sprintf("UPDATE %s SET status = ? WHERE id = ?", tableName), orderModel.OrderStatusPaid, orderID)
	if err != nil {
		t.Fatalf("更新订单状态失败: %v", err)
	}

	// 测试非法状态转换：已支付 -> 已支付（重复支付）
	payReq := &orderModel.OrderPayRequest{
		OrderID: orderID,
		UserID:  userID,
	}

	err = testOrderService.PayOrder(ctx, payReq)
	if err == nil {
		t.Error("重复支付订单应该失败，但成功了")
	} else {
		t.Logf("期望的错误（重复支付）: %v", err)
	}

	// 测试非法状态转换：已支付 -> 已取消
	cancelReq := &orderModel.OrderCancelRequest{
		OrderID: orderID,
		UserID:  userID,
	}

	err = testOrderService.CancelOrder(ctx, cancelReq)
	if err == nil {
		t.Error("取消已支付订单应该失败，但成功了")
	} else {
		t.Logf("期望的错误（取消已支付订单）: %v", err)
	}

	// 创建第二个订单并取消
	orderReq2 := &orderModel.OrderCreateRequest{
		UserID:    userID,
		ProductID: productID,
		Quantity:  quantity,
	}

	orderInfo2, err := testOrderService.CreateOrder(ctx, orderReq2)
	if err != nil {
		t.Fatalf("创建第二个订单失败: %v", err)
	}

	orderID2 := orderInfo2.ID

	// 取消订单
	cancelReq2 := &orderModel.OrderCancelRequest{
		OrderID: orderID2,
		UserID:  userID,
	}

	err = testOrderService.CancelOrder(ctx, cancelReq2)
	if err != nil {
		t.Fatalf("取消订单失败: %v", err)
	}

	// 测试非法状态转换：已取消 -> 已支付
	payReq2 := &orderModel.OrderPayRequest{
		OrderID: orderID2,
		UserID:  userID,
	}

	err = testOrderService.PayOrder(ctx, payReq2)
	if err == nil {
		t.Error("支付已取消订单应该失败，但成功了")
	} else {
		t.Logf("期望的错误（支付已取消订单）: %v", err)
	}

	// 测试非法状态转换：已取消 -> 已取消（重复取消）
	err = testOrderService.CancelOrder(ctx, cancelReq2)
	if err == nil {
		t.Error("重复取消订单应该失败，但成功了")
	} else {
		t.Logf("期望的错误（重复取消）: %v", err)
	}
}
