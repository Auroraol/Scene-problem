package breaker

import (
	"context"
	"errors"
	"fmt"
	"testing"
	"time"

	"github.com/ammyhaber/seckill/pkg/breaker"
)

// TestAdaptiveBreakerEdgeCases 测试自适应熔断器的边缘情况
func TestAdaptiveBreakerEdgeCases(t *testing.T) {
	t.Run("ZeroErrorThreshold", func(t *testing.T) {
		// 测试错误阈值为0的情况，任何错误都会触发熔断
		b := breaker.NewAdaptiveBreaker(
			breaker.WithErrorThreshold(0),
			breaker.WithRecoveryWindow(1*time.Second),
		)

		// 单个错误应触发熔断
		err := b.Execute(func() error {
			return errors.New("单个错误")
		})
		if err == nil {
			t.Fatal("期望返回错误，但返回nil")
		}

		// 此时熔断器应该已开启
		if b.GetState() != breaker.StateOpen {
			t.Fatalf("期望熔断器状态为开启，实际为: %v", b.GetState())
		}

		// 熔断后调用应直接返回熔断错误
		err = b.Execute(func() error {
			t.Fatal("熔断状态下不应执行此函数")
			return nil
		})
		if err != breaker.ErrCircuitOpenAdaptive {
			t.Fatalf("期望熔断错误，实际为: %v", err)
		}
	})

	t.Run("HighErrorThreshold", func(t *testing.T) {
		// 测试错误阈值为1的情况，即100%错误率才触发熔断
		b := breaker.NewAdaptiveBreaker(
			breaker.WithErrorThreshold(1.0),
			breaker.WithRecoveryWindow(1*time.Second),
		)

		// 混合成功和错误请求
		for i := 0; i < 5; i++ {
			b.Execute(func() error {
				if i%2 == 0 {
					return errors.New("错误请求")
				}
				return nil
			})
		}

		// 此时熔断器应该仍是关闭状态
		if b.GetState() != breaker.StateClosed {
			t.Fatalf("期望熔断器状态为关闭，实际为: %v", b.GetState())
		}

		// 连续10个错误请求
		for i := 0; i < 10; i++ {
			b.Execute(func() error {
				return errors.New("错误请求")
			})
		}

		// 此时熔断器应该已开启
		if b.GetState() != breaker.StateOpen {
			t.Fatalf("期望熔断器状态为开启，实际为: %v", b.GetState())
		}
	})

	t.Run("ZeroRecoveryWindow", func(t *testing.T) {
		// 测试恢复窗口为0的情况
		b := breaker.NewAdaptiveBreaker(
			breaker.WithErrorThreshold(0.5),
			breaker.WithRecoveryWindow(0),
		)

		// 触发熔断
		for i := 0; i < 5; i++ {
			b.Execute(func() error {
				return errors.New("错误请求")
			})
		}

		// 此时熔断器应该已开启
		if b.GetState() != breaker.StateOpen {
			t.Fatalf("期望熔断器状态为开启，实际为: %v", b.GetState())
		}

		// 验证熔断器的行为
		// 当恢复窗口为0时，熔断器会维持在开启状态，直到有特定的操作触发状态切换
		// 这符合实际需求，避免熔断器过于频繁地切换状态
		t.Logf("恢复窗口为0时，熔断器状态为: %v", b.GetState())
	})

	t.Run("ContextCancellation", func(t *testing.T) {
		// 测试上下文取消对熔断器的影响
		b := breaker.NewAdaptiveBreaker(
			breaker.WithErrorThreshold(0.5),
			breaker.WithRecoveryWindow(1*time.Second),
		)

		// 注册一个降级函数
		b.RegisterFallback("testOp", func(err error) (interface{}, error) {
			return "降级响应", nil
		})

		// 创建可取消的上下文
		ctx, cancel := context.WithCancel(context.Background())

		// 先执行一些正常请求
		for i := 0; i < 5; i++ {
			b.ExecuteWithResult(ctx, "testOp", func() (interface{}, error) {
				return "正常响应", nil
			})
		}

		// 取消上下文
		cancel()

		// 使用已取消的上下文执行请求
		result, err := b.ExecuteWithResult(ctx, "testOp", func() (interface{}, error) {
			t.Fatal("上下文已取消，不应执行此函数")
			return nil, nil
		})

		// 验证是否返回降级响应
		if err != nil {
			t.Fatalf("期望无错误，实际为: %v", err)
		}
		if result != "降级响应" {
			t.Fatalf("期望降级响应，实际为: %v", result)
		}
	})

	t.Run("ConcurrentStateTransition", func(t *testing.T) {
		// 测试并发状态转换
		b := breaker.NewAdaptiveBreaker(
			breaker.WithErrorThreshold(0.5),
			breaker.WithRecoveryWindow(100*time.Millisecond),
		)

		// 第一阶段：生成足够的错误来触发熔断
		for i := 0; i < 10; i++ {
			b.Execute(func() error {
				return errors.New("错误请求")
			})
		}

		// 确认熔断器已经开启
		if b.GetState() != breaker.StateOpen {
			t.Fatalf("期望熔断器状态为开启，实际为: %v", b.GetState())
		}

		// 等待熔断器进入恢复期
		time.Sleep(100 * time.Millisecond)

		// 第二阶段：并发发送请求，部分会成功，部分会失败
		done := make(chan struct{})
		go func() {
			for i := 0; i < 20; i++ {
				go func(index int) {
					err := b.Execute(func() error {
						// 偶数请求返回成功，奇数请求返回错误
						if index%2 == 0 {
							return nil
						}
						return fmt.Errorf("错误 %d", index)
					})
					if err != nil && err != breaker.ErrCircuitOpenAdaptive {
						t.Logf("请求 %d 返回错误: %v", index, err)
					}
				}(i)
				time.Sleep(10 * time.Millisecond)
			}
			close(done)
		}()

		// 等待所有并发请求完成
		<-done

		// 等待状态稳定
		time.Sleep(200 * time.Millisecond)

		// 根据错误率，熔断器可能回到开启状态或关闭状态
		state := b.GetState()
		t.Logf("最终熔断器状态: %v", state)
	})
}

// TestAdaptiveBreakerRecovery 测试自适应熔断器的恢复行为
func TestAdaptiveBreakerRecovery(t *testing.T) {
	// 创建熔断器，设置错误阈值为0.5，恢复窗口为1秒，恢复率为0.2
	b := breaker.NewAdaptiveBreaker(
		breaker.WithErrorThreshold(0.5),
		breaker.WithRecoveryWindow(1*time.Second),
		breaker.WithRecoveryRate(0.2),
	)

	// 触发熔断
	for i := 0; i < 10; i++ {
		b.Execute(func() error {
			return errors.New("错误请求")
		})
	}

	// 确认熔断器已开启
	if b.GetState() != breaker.StateOpen {
		t.Fatalf("期望熔断器状态为开启，实际为: %v", b.GetState())
	}

	// 等待进入恢复期
	time.Sleep(1 * time.Second)

	// 发送一个请求，这将触发状态切换到半开状态
	b.Execute(func() error {
		return nil // 成功请求
	})

	// 此时熔断器应该处于半开状态
	if b.GetState() != breaker.StateHalfOpen {
		t.Fatalf("期望熔断器状态为半开，实际为: %v", b.GetState())
	}

	// 在半开状态发送一些成功请求
	successCount := 0
	for i := 0; i < 20; i++ {
		err := b.Execute(func() error {
			return nil // 全部成功
		})
		if err == nil {
			successCount++
		}
	}

	// 验证成功请求数量大约为总请求的20%（恢复率）
	t.Logf("半开状态成功请求: %d/20", successCount)
	if successCount < 2 || successCount > 8 {
		t.Errorf("恢复期请求通过率不符合预期，期望约为20%%，实际为%d%%", successCount*5)
	}

	// 等待足够时间让熔断器恢复
	time.Sleep(3 * time.Second)

	// 发送一个请求，确保状态更新
	b.Execute(func() error {
		return nil
	})

	// 此时熔断器应该回到关闭状态
	if b.GetState() != breaker.StateClosed {
		t.Fatalf("期望熔断器状态为关闭，实际为: %v", b.GetState())
	}

	// 现在所有请求都应该通过
	for i := 0; i < 5; i++ {
		err := b.Execute(func() error {
			return nil
		})
		if err != nil {
			t.Errorf("恢复后请求应成功，但返回错误: %v", err)
		}
	}
}

// TestBreakerFallback 测试熔断器降级功能的各种场景
func TestBreakerFallback(t *testing.T) {
	// 创建熔断器
	b := breaker.NewAdaptiveBreaker()

	t.Run("NormalFallback", func(t *testing.T) {
		// 注册正常的降级函数
		b.RegisterFallback("normal", func(err error) (interface{}, error) {
			return "降级响应", nil
		})

		// 触发熔断
		for i := 0; i < 10; i++ {
			b.Execute(func() error {
				return errors.New("错误请求")
			})
		}

		// 确认熔断器已开启
		if b.GetState() != breaker.StateOpen {
			t.Fatalf("期望熔断器状态为开启，实际为: %v", b.GetState())
		}

		// 执行请求，应触发降级
		result, err := b.ExecuteWithResult(context.Background(), "normal", func() (interface{}, error) {
			t.Fatal("熔断状态不应执行此函数")
			return nil, nil
		})

		// 验证返回降级响应
		if err != nil {
			t.Fatalf("期望无错误，实际为: %v", err)
		}
		if result != "降级响应" {
			t.Fatalf("期望降级响应，实际为: %v", result)
		}
	})

	// 重置熔断器
	b.Reset()

	t.Run("FallbackWithError", func(t *testing.T) {
		// 注册返回错误的降级函数
		b.RegisterFallback("withError", func(err error) (interface{}, error) {
			return nil, errors.New("降级失败")
		})

		// 触发熔断
		for i := 0; i < 10; i++ {
			b.Execute(func() error {
				return errors.New("错误请求")
			})
		}

		// 执行请求，应触发降级
		result, err := b.ExecuteWithResult(context.Background(), "withError", func() (interface{}, error) {
			t.Fatal("熔断状态不应执行此函数")
			return nil, nil
		})

		// 验证返回降级错误
		if err == nil {
			t.Fatal("期望返回错误，但返回nil")
		}
		if err.Error() != "降级失败" {
			t.Fatalf("期望降级错误，实际为: %v", err)
		}
		if result != nil {
			t.Fatalf("期望nil结果，实际为: %v", result)
		}
	})

	// 重置熔断器
	b.Reset()

	t.Run("NoRegisteredFallback", func(t *testing.T) {
		// 不注册降级函数

		// 触发熔断
		for i := 0; i < 10; i++ {
			b.Execute(func() error {
				return errors.New("错误请求")
			})
		}

		// 执行没有注册降级函数的操作
		result, err := b.ExecuteWithResult(context.Background(), "notExist", func() (interface{}, error) {
			t.Fatal("熔断状态不应执行此函数")
			return nil, nil
		})

		// 验证返回熔断错误
		if err != breaker.ErrCircuitOpenAdaptive {
			t.Fatalf("期望熔断错误，实际为: %v", err)
		}
		if result != nil {
			t.Fatalf("期望nil结果，实际为: %v", result)
		}
	})
}
