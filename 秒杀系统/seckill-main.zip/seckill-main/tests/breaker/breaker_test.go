package breaker

import (
	"context"
	"errors"
	"testing"
	"time"

	"github.com/ammyhaber/seckill/pkg/breaker"
)

func TestAdaptiveBreaker_Execute(t *testing.T) {
	// 添加测试超时
	if testing.Short() {
		t.Skip("跳过需要等待的测试")
	}

	// 设置测试超时
	t.Parallel()
	timeout := time.AfterFunc(5*time.Second, func() {
		t.Error("测试超时")
		t.FailNow()
	})
	defer timeout.Stop()

	// 创建熔断器，使用更小的阈值以便于测试
	adaptiveBreaker := breaker.NewAdaptiveBreaker(
		breaker.WithErrorThreshold(0.3),                  // 降低错误率阈值到30%以便测试
		breaker.WithMinRequestCount(5),                   // 最少5个请求触发熔断
		breaker.WithRecoveryWindow(100*time.Millisecond), // 减少恢复窗口到100毫秒
		breaker.WithRecoveryRate(0.1),                    // 恢复期间允许10%的请求通过
	)

	// 测试正常情况
	for i := 0; i < 10; i++ {
		err := adaptiveBreaker.Execute(func() error {
			return nil // 成功请求
		})
		if err != nil {
			t.Errorf("预期成功，但收到错误: %v", err)
		}
	}

	// 验证状态
	if state := adaptiveBreaker.GetState(); state != breaker.StateClosed {
		t.Errorf("预期状态为关闭，但得到: %d", state)
	}

	t.Logf("触发熔断前，状态: %d", adaptiveBreaker.GetState())

	// 测试触发熔断
	for i := 0; i < 10; i++ { // 增加错误请求次数
		_ = adaptiveBreaker.Execute(func() error {
			return errors.New("模拟错误") // 失败请求
		})
		t.Logf("执行失败请求 %d 次后，状态: %d", i+1, adaptiveBreaker.GetState())
	}

	// 验证状态
	if state := adaptiveBreaker.GetState(); state != breaker.StateOpen {
		t.Errorf("预期状态为打开，但得到: %d", state)
	}

	t.Logf("熔断后状态: %d", adaptiveBreaker.GetState())

	// 验证熔断器打开时请求被拒绝
	err := adaptiveBreaker.Execute(func() error {
		t.Log("这不应该被执行")
		return nil
	})
	t.Logf("拒绝请求检查，错误: %v", err)
	if err == nil || err.Error() != breaker.ErrCircuitOpenAdaptive.Error() {
		t.Errorf("预期错误 %v, 但得到: %v", breaker.ErrCircuitOpenAdaptive, err)
	}

	// 等待恢复窗口期
	t.Log("等待恢复窗口期...")
	time.Sleep(200 * time.Millisecond) // 缩短等待时间
	t.Logf("等待后状态: %d", adaptiveBreaker.GetState())

	// 第一个请求应该允许通过（半开状态）
	success := false
	err = adaptiveBreaker.Execute(func() error {
		success = true
		return nil
	})
	t.Logf("半开状态下探测请求执行: success=%v, err=%v, 熔断器状态=%d",
		success, err, adaptiveBreaker.GetState())
	if !success {
		t.Error("恢复窗口后第一个请求应该通过，但被拒绝")
	}

	// 验证状态
	if state := adaptiveBreaker.GetState(); state != breaker.StateHalfOpen {
		t.Errorf("预期状态为半开，但得到: %d", state)
	}

	// 手动重置熔断器
	adaptiveBreaker.Reset()

	// 验证状态为关闭
	if state := adaptiveBreaker.GetState(); state != breaker.StateClosed {
		t.Errorf("重置后期望状态为关闭，但得到: %d", state)
	}

	// 测试在熔断器关闭后，请求正常执行
	for i := 0; i < 5; i++ {
		err := adaptiveBreaker.Execute(func() error {
			return nil // 成功请求
		})
		if err != nil {
			t.Errorf("预期成功，但收到错误: %v", err)
		}
		t.Logf("熔断器关闭后执行成功请求 %d 次，状态: %d",
			i+1, adaptiveBreaker.GetState())
	}

	// 验证状态
	if state := adaptiveBreaker.GetState(); state != breaker.StateClosed {
		t.Errorf("预期状态为关闭，但得到: %d", state)
	}
}

func TestAdaptiveBreaker_ExecuteWithResult(t *testing.T) {
	// 添加测试超时
	if testing.Short() {
		t.Skip("跳过需要等待的测试")
	}

	// 设置测试超时
	t.Parallel()
	timeout := time.AfterFunc(5*time.Second, func() {
		t.Error("测试超时")
		t.FailNow()
	})
	defer timeout.Stop()

	// 创建熔断器
	adaptiveBreaker := breaker.NewAdaptiveBreaker(
		breaker.WithErrorThreshold(0.5),
		breaker.WithMinRequestCount(5),
		breaker.WithRecoveryWindow(100*time.Millisecond), // 减少恢复窗口到100毫秒
	)

	// 注册降级函数
	adaptiveBreaker.RegisterFallback("test", func(err error) (interface{}, error) {
		return "降级结果", nil
	})

	// 测试正常请求
	result, err := adaptiveBreaker.ExecuteWithResult(context.Background(), "test", func() (interface{}, error) {
		return "正常结果", nil
	})
	if err != nil {
		t.Errorf("预期成功，但收到错误: %v", err)
	}
	if result != "正常结果" {
		t.Errorf("预期结果为 '正常结果'，但得到: %v", result)
	}

	// 测试触发熔断
	for i := 0; i < 6; i++ {
		_, _ = adaptiveBreaker.ExecuteWithResult(context.Background(), "test", func() (interface{}, error) {
			return nil, errors.New("模拟错误")
		})
	}

	// 验证熔断器打开时返回降级结果
	result, err = adaptiveBreaker.ExecuteWithResult(context.Background(), "test", func() (interface{}, error) {
		return "不应执行", nil
	})
	if err != nil {
		t.Errorf("预期降级成功，但收到错误: %v", err)
	}
	if result != "降级结果" {
		t.Errorf("预期结果为 '降级结果'，但得到: %v", result)
	}

	// 测试上下文取消
	cancelCtx, cancel := context.WithCancel(context.Background())
	cancel() // 立即取消
	result, _ = adaptiveBreaker.ExecuteWithResult(cancelCtx, "test", func() (interface{}, error) {
		return "不应执行", nil
	})
	if result != "降级结果" {
		t.Errorf("上下文取消后，预期结果为 '降级结果'，但得到: %v", result)
	}

	// 测试无降级函数情况
	_, err = adaptiveBreaker.ExecuteWithResult(context.Background(), "nonexistent", func() (interface{}, error) {
		return nil, errors.New("自定义错误")
	})
	if err == nil || err.Error() != "自定义错误" {
		t.Errorf("预期错误 '自定义错误'，但得到: %v", err)
	}
}

func TestAdaptiveBreaker_Reset(t *testing.T) {
	// 添加测试超时
	if testing.Short() {
		t.Skip("跳过需要等待的测试")
	}

	// 设置测试超时
	t.Parallel()
	timeout := time.AfterFunc(5*time.Second, func() {
		t.Error("测试超时")
		t.FailNow()
	})
	defer timeout.Stop()

	adaptiveBreaker := breaker.NewAdaptiveBreaker(
		breaker.WithErrorThreshold(0.5),
		breaker.WithMinRequestCount(5),
	)

	// 触发熔断
	for i := 0; i < 6; i++ {
		_ = adaptiveBreaker.Execute(func() error {
			return errors.New("模拟错误")
		})
	}

	// 验证状态为打开
	if state := adaptiveBreaker.GetState(); state != breaker.StateOpen {
		t.Errorf("预期状态为打开，但得到: %d", state)
	}

	// 重置熔断器
	adaptiveBreaker.Reset()

	// 验证状态为关闭
	if state := adaptiveBreaker.GetState(); state != breaker.StateClosed {
		t.Errorf("预期状态为关闭，但得到: %d", state)
	}

	// 验证可以正常执行请求
	err := adaptiveBreaker.Execute(func() error {
		return nil
	})
	if err != nil {
		t.Errorf("重置后预期成功，但收到错误: %v", err)
	}
}

// TestContextCancellation 测试上下文取消对goroutine的影响
func TestContextCancellation(t *testing.T) {
	// 设置测试超时
	t.Parallel()
	timeout := time.AfterFunc(5*time.Second, func() {
		t.Error("测试超时")
		t.FailNow()
	})
	defer timeout.Stop()

	// 创建一个带取消功能的上下文
	ctx, cancel := context.WithCancel(context.Background())
	defer cancel()

	// 创建熔断器
	adaptiveBreaker := breaker.NewAdaptiveBreaker(
		breaker.WithErrorThreshold(0.5),
		breaker.WithMinRequestCount(5),
	)

	// 执行一些请求
	for i := 0; i < 3; i++ {
		_, err := adaptiveBreaker.ExecuteWithResult(ctx, "test", func() (interface{}, error) {
			return "测试结果", nil
		})
		if err != nil {
			t.Errorf("执行请求失败: %v", err)
		}
	}

	// 取消上下文
	cancel()

	// 验证取消后的行为
	_, err := adaptiveBreaker.ExecuteWithResult(ctx, "test", func() (interface{}, error) {
		t.Error("上下文已取消，不应执行此函数")
		return nil, nil
	})

	// 应该返回上下文取消错误
	if err == nil {
		t.Error("预期上下文取消错误，但得到nil")
	}
}
