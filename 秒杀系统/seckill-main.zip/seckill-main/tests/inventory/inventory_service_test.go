package inventory

import (
	"context"
	"encoding/json"
	"fmt"
	"log"
	"os"
	"path/filepath"
	"testing"

	"github.com/ammyhaber/seckill/config"
	"github.com/ammyhaber/seckill/service/inventory/cache"
	"github.com/ammyhaber/seckill/service/inventory/dao"
	"github.com/ammyhaber/seckill/service/inventory/service"
	"github.com/go-redis/redis/v8"
	_ "github.com/go-sql-driver/mysql"
	"github.com/jmoiron/sqlx"
)

var (
	invTestDB                *sqlx.DB
	testRedis                *redis.Client
	testInventoryDAO         *dao.InventoryDAO
	testInventoryLockDAO     *dao.InventoryLockDAO
	testInventoryCache       *cache.RedisCache
	testInventoryService     service.InventoryServiceInterface
	testInventoryLockService service.InventoryLockServiceInterface
	testConfig               *config.Config // 测试配置
)

// loadTestConfig 从配置文件加载测试配置
func loadTestConfig() (*config.Config, error) {
	// 优先使用环境变量中指定的测试配置文件
	configFile := os.Getenv("TEST_CONFIG_FILE")
	if configFile == "" {
		// 默认使用项目根目录下的测试配置文件
		// 尝试确定项目根目录
		workDir, err := os.Getwd()
		if err != nil {
			return nil, fmt.Errorf("获取当前工作目录失败: %v", err)
		}

		// 假设当前工作目录是项目根目录或者其子目录
		// 尝试向上查找，直到找到config目录
		for {
			configPath := filepath.Join(workDir, "config", "config_test.json")
			if _, err := os.Stat(configPath); err == nil {
				configFile = configPath
				break
			}

			// 尝试向上一级目录
			parent := filepath.Dir(workDir)
			if parent == workDir {
				// 已经到达根目录，无法继续向上
				return nil, fmt.Errorf("找不到测试配置文件")
			}
			workDir = parent
		}
	}

	// 读取配置文件
	data, err := os.ReadFile(configFile)
	if err != nil {
		return nil, fmt.Errorf("读取测试配置文件失败: %v", err)
	}

	// 解析配置文件
	var cfg config.Config
	if err := json.Unmarshal(data, &cfg); err != nil {
		return nil, fmt.Errorf("解析测试配置文件失败: %v", err)
	}

	return &cfg, nil
}

// setupTestDatabase 初始化测试数据库并插入测试数据
func setupTestDatabase(db *sqlx.DB) error {
	// 创建测试表
	err := createInventoryTestTables(db)
	if err != nil {
		return fmt.Errorf("创建测试表失败: %v", err)
	}

	// 插入库存测试数据
	_, err = db.Exec(`INSERT INTO inventory (product_id, total, available, locked, version) 
                    VALUES (10001, 1000, 1000, 0, 1), (10002, 500, 500, 0, 1)
                    ON DUPLICATE KEY UPDATE total=VALUES(total), available=VALUES(available), 
                    locked=VALUES(locked), version=VALUES(version)`)
	if err != nil {
		return fmt.Errorf("插入库存测试数据失败: %v", err)
	}

	// 插入商品测试数据
	_, err = db.Exec(`INSERT INTO product (id, name, description, price, stock, status) 
                    VALUES (10001, '测试商品1', '测试商品1描述', 100.00, 1000, 1), 
                           (10002, '测试商品2', '测试商品2描述', 200.00, 500, 1)
                    ON DUPLICATE KEY UPDATE name=VALUES(name), description=VALUES(description), 
                    price=VALUES(price), stock=VALUES(stock), status=VALUES(status)`)
	if err != nil {
		return fmt.Errorf("插入商品测试数据失败: %v", err)
	}

	return nil
}

// initTestServices 初始化测试服务
func initTestServices() error {
	// 加载测试配置
	var err error
	testConfig, err = loadTestConfig()
	if err != nil {
		return fmt.Errorf("加载测试配置失败: %v", err)
	}

	// 创建测试数据库连接
	mysqlCfg := testConfig.MySQL
	dsn := fmt.Sprintf("%s:%s@tcp(%s:%d)/%s?%s",
		mysqlCfg.Username, mysqlCfg.Password, mysqlCfg.Host, mysqlCfg.Port,
		mysqlCfg.Database, mysqlCfg.Params)

	invTestDB, err = sqlx.Connect("mysql", dsn)
	if err != nil {
		return fmt.Errorf("连接数据库失败: %v", err)
	}

	// 设置数据库连接参数
	invTestDB.SetMaxIdleConns(mysqlCfg.MaxIdleConns)
	invTestDB.SetMaxOpenConns(mysqlCfg.MaxOpenConns)
	invTestDB.SetConnMaxLifetime(mysqlCfg.ConnMaxLifetime)

	// 设置Redis客户端
	redisCfg := testConfig.Redis
	testRedis = redis.NewClient(&redis.Options{
		Addr:         fmt.Sprintf("%s:%d", redisCfg.Host, redisCfg.Port),
		Password:     redisCfg.Password,
		DB:           redisCfg.DB,
		PoolSize:     redisCfg.PoolSize,
		MinIdleConns: redisCfg.MinIdleConns,
		DialTimeout:  redisCfg.DialTimeout,
		ReadTimeout:  redisCfg.ReadTimeout,
		WriteTimeout: redisCfg.WriteTimeout,
	})

	// 初始化测试的服务
	testInventoryDAO = dao.NewInventoryDAO(invTestDB)
	testInventoryLockDAO = dao.NewInventoryLockDAO(invTestDB)
	testInventoryCache = cache.NewRedisCache(testRedis)
	testInventoryService = service.NewInventoryService(testInventoryDAO, testInventoryCache)
	testInventoryLockService = service.NewInventoryLockService(testInventoryDAO, testInventoryLockDAO, testInventoryCache)

	// 初始化测试数据
	err = setupTestDatabase(invTestDB)
	if err != nil {
		return err
	}

	// 初始化Redis缓存
	ctx := context.Background()
	// 清理可能存在的旧数据
	testRedis.FlushDB(ctx)

	// 初始化缓存
	err = testInventoryService.InitCache(ctx)
	if err != nil {
		return fmt.Errorf("初始化缓存失败: %v", err)
	}

	return nil
}

// TestInventoryServiceSetup 初始化库存服务测试环境
func TestInventoryServiceSetup(t *testing.T) {
	err := initTestServices()
	if err != nil {
		t.Fatalf("初始化测试服务失败: %v", err)
	}
}

// TestMain 测试主函数，负责初始化和清理资源
func TestMain(m *testing.M) {
	var err error

	// 初始化测试服务
	err = initTestServices()
	if err != nil {
		log.Fatalf("初始化测试服务失败: %v", err)
	}

	// 运行测试
	code := m.Run()

	// 测试完成后清理数据库和连接
	if invTestDB != nil {
		invTestDB.Close()
	}

	if testRedis != nil {
		testRedis.Close()
	}

	os.Exit(code)
}

// TestGetInventory 测试获取库存
func TestGetInventory(t *testing.T) {
	ctx := context.Background()

	// 测试获取存在的商品库存
	detail, err := testInventoryService.GetInventoryDetail(ctx, 10001)
	if err != nil {
		t.Fatalf("获取库存失败: %v", err)
	}

	if detail.ProductID != 10001 || detail.Available != 1000 || detail.Locked != 0 {
		t.Errorf("库存数据不匹配，期望: {ProductID:10001, Available:1000, Locked:0}, 实际: %+v", detail)
	}

	// 测试获取不存在的商品库存
	_, err = testInventoryService.GetInventoryDetail(ctx, 99999)
	if err == nil {
		t.Error("期望获取不存在商品返回错误，但没有错误")
	}
}

// TestDecrInventory 测试扣减库存
func TestDecrInventory(t *testing.T) {
	ctx := context.Background()

	// 测试正常扣减库存
	success, err := testInventoryService.DecrInventory(ctx, 10001, 50)
	if err != nil {
		t.Fatalf("扣减库存失败: %v", err)
	}
	if !success {
		t.Error("扣减库存应该成功，但返回失败")
	}

	// 验证库存是否正确扣减
	detail, _ := testInventoryService.GetInventoryDetail(ctx, 10001)
	if detail.Available != 950 || detail.Locked != 50 {
		t.Errorf("扣减后库存数据不匹配，期望: {Available:950, Locked:50}, 实际: {Available:%d, Locked:%d}",
			detail.Available, detail.Locked)
	}

	// 测试库存不足
	success, err = testInventoryService.DecrInventory(ctx, 10001, 2000)
	if err == nil || success {
		t.Error("库存不足应该返回错误，但没有错误")
	}

	// 测试不存在的商品
	success, err = testInventoryService.DecrInventory(ctx, 99999, 10)
	if err == nil || success {
		t.Error("不存在的商品应该返回错误，但没有错误")
	}
}

// TestConfirmDeduction 测试确认扣减
func TestConfirmDeduction(t *testing.T) {
	ctx := context.Background()

	// 获取初始库存状态
	initDetail, err := testInventoryService.GetInventoryDetail(ctx, 10002)
	if err != nil {
		t.Fatalf("获取初始库存失败: %v", err)
	}
	initialAvailable := initDetail.Available

	// 先扣减库存
	success, err := testInventoryService.DecrInventory(ctx, 10002, 50)
	if err != nil || !success {
		t.Fatalf("扣减库存失败: %v", err)
	}

	// 验证扣减后的库存
	afterDecrDetail, err := testInventoryService.GetInventoryDetail(ctx, 10002)
	if err != nil {
		t.Fatalf("获取扣减后库存失败: %v", err)
	}
	if afterDecrDetail.Available != initialAvailable-50 || afterDecrDetail.Locked != 50 {
		t.Fatalf("扣减库存后状态不正确，期望: {Available:%d, Locked:50}, 实际: {Available:%d, Locked:%d}",
			initialAvailable-50, afterDecrDetail.Available, afterDecrDetail.Locked)
	}

	// 确认扣减
	err = testInventoryService.ConfirmDeduction(ctx, 10002, 50)
	if err != nil {
		t.Fatalf("确认扣减失败: %v", err)
	}

	// 验证库存状态
	afterConfirmDetail, err := testInventoryService.GetInventoryDetail(ctx, 10002)
	if err != nil {
		t.Fatalf("获取确认扣减后库存失败: %v", err)
	}
	if afterConfirmDetail.Available != initialAvailable-50 || afterConfirmDetail.Locked != 0 {
		t.Errorf("确认扣减后库存数据不匹配，期望: {Available:%d, Locked:0}, 实际: {Available:%d, Locked:%d}",
			initialAvailable-50, afterConfirmDetail.Available, afterConfirmDetail.Locked)
	}
}

// TestCancelDeduction 测试取消扣减
func TestCancelDeduction(t *testing.T) {
	ctx := context.Background()

	// 获取初始库存状态
	initDetail, err := testInventoryService.GetInventoryDetail(ctx, 10002)
	if err != nil {
		t.Fatalf("获取初始库存失败: %v", err)
	}
	initialAvailable := initDetail.Available

	// 先扣减库存
	success, err := testInventoryService.DecrInventory(ctx, 10002, 50)
	if err != nil || !success {
		t.Fatalf("扣减库存失败: %v", err)
	}

	// 验证扣减后的库存
	afterDecrDetail, err := testInventoryService.GetInventoryDetail(ctx, 10002)
	if err != nil {
		t.Fatalf("获取扣减后库存失败: %v", err)
	}
	if afterDecrDetail.Available != initialAvailable-50 || afterDecrDetail.Locked != 50 {
		t.Fatalf("扣减库存后状态不正确，期望: {Available:%d, Locked:50}, 实际: {Available:%d, Locked:%d}",
			initialAvailable-50, afterDecrDetail.Available, afterDecrDetail.Locked)
	}

	// 取消扣减
	err = testInventoryService.CancelDeduction(ctx, 10002, 50)
	if err != nil {
		t.Fatalf("取消扣减失败: %v", err)
	}

	// 验证库存状态
	afterCancelDetail, err := testInventoryService.GetInventoryDetail(ctx, 10002)
	if err != nil {
		t.Fatalf("获取取消扣减后库存失败: %v", err)
	}
	if afterCancelDetail.Available != initialAvailable || afterCancelDetail.Locked != 0 {
		t.Errorf("取消扣减后库存数据不匹配，期望: {Available:%d, Locked:0}, 实际: {Available:%d, Locked:%d}",
			initialAvailable, afterCancelDetail.Available, afterCancelDetail.Locked)
	}
}

// createInventoryTestTables 创建测试所需的表
func createInventoryTestTables(db *sqlx.DB) error {
	// 创建库存表
	_, err := db.Exec(`
		CREATE TABLE IF NOT EXISTS inventory (
			product_id BIGINT PRIMARY KEY,
			total INT NOT NULL,
			available INT NOT NULL,
			locked INT NOT NULL,
			version INT NOT NULL,
			created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
			updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
		)
	`)
	if err != nil {
		return fmt.Errorf("创建库存表失败: %v", err)
	}

	// 创建库存锁表
	_, err = db.Exec(`
		CREATE TABLE IF NOT EXISTS inventory_lock (
			id BIGINT AUTO_INCREMENT PRIMARY KEY,
			product_id BIGINT NOT NULL,
			order_id VARCHAR(64) NOT NULL,
			quantity INT NOT NULL,
			status TINYINT NOT NULL DEFAULT 1,
			lock_time TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
			unlock_time TIMESTAMP NULL,
			expire_time TIMESTAMP NULL,
			INDEX idx_product_id(product_id),
			INDEX idx_order_id(order_id)
		)
	`)
	if err != nil {
		return fmt.Errorf("创建库存锁表失败: %v", err)
	}

	// 创建商品表
	_, err = db.Exec(`
		CREATE TABLE IF NOT EXISTS product (
			id BIGINT PRIMARY KEY,
			name VARCHAR(255) NOT NULL,
			description TEXT,
			price DECIMAL(10,2) NOT NULL,
			stock INT NOT NULL,
			status INT NOT NULL DEFAULT 1,
			created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
			updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
		)
	`)
	if err != nil {
		return fmt.Errorf("创建商品表失败: %v", err)
	}

	return nil
}
