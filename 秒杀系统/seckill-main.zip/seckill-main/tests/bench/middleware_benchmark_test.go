package tests

import (
	"context"
	"errors"
	"math/rand"
	"testing"
	"time"

	"github.com/ammyhaber/seckill/pkg/breaker"
	"github.com/ammyhaber/seckill/pkg/limiter"
	"github.com/go-redis/redis/v8"
)

// setupTestRedisClient 创建Redis客户端
func setupTestRedisClient() *redis.Client {
	return redis.NewClient(&redis.Options{
		Addr:     "localhost:6379",
		Password: "",
		DB:       0,
	})
}

// BenchmarkTokenBucket 基准测试令牌桶限流器性能
func BenchmarkTokenBucket(b *testing.B) {
	// 创建令牌桶限流器，每秒1000个请求，最多积累2000个令牌
	tb := limiter.NewTokenBucket(1000, 2000)

	b.ResetTimer()
	b.RunParallel(func(pb *testing.PB) {
		for pb.Next() {
			tb.Allow()
		}
	})
}

// BenchmarkRedisRateLimiter 基准测试Redis分布式限流器性能
func BenchmarkRedisRateLimiter(b *testing.B) {
	ctx := context.Background()
	redisClient := setupTestRedisClient()

	// 测试Redis连接
	_, err := redisClient.Ping(ctx).Result()
	if err != nil {
		b.Skip("Redis不可用，跳过分布式限流测试")
	}

	// 创建唯一键名，避免多次测试相互干扰
	keyPrefix := "benchmark:ratelimit:" + time.Now().Format("20060102150405")

	// 创建分布式限流器
	rl := limiter.NewRedisRateLimiter(redisClient, keyPrefix, 10000, 1*time.Second)

	// 清理之前可能存在的数据
	redisClient.Del(ctx, keyPrefix+":global")
	defer redisClient.Del(ctx, keyPrefix+":global")

	b.ResetTimer()
	b.RunParallel(func(pb *testing.PB) {
		for pb.Next() {
			rl.Allow()
		}
	})
}

// BenchmarkUserIPRateLimiter 基准测试用户和IP限流器性能
func BenchmarkUserIPRateLimiter(b *testing.B) {
	ctx := context.Background()
	redisClient := setupTestRedisClient()

	// 测试Redis连接
	_, err := redisClient.Ping(ctx).Result()
	if err != nil {
		b.Skip("Redis不可用，跳过用户IP限流测试")
	}

	// 创建唯一键前缀，避免多次测试相互干扰
	keyPrefix := "benchmark:" + time.Now().Format("20060102150405")

	// 创建用户限流器
	userLimiter := limiter.NewUserRateLimiter(redisClient, 10000, 1*time.Second)

	// 创建IP限流器
	ipLimiter := limiter.NewIPRateLimiter(redisClient, 10000, 1*time.Second)

	// 预生成用户ID和IP
	const userCount = 100
	const ipCount = 200
	userIDs := make([]string, userCount)
	ipAddrs := make([]string, ipCount)

	for i := 0; i < userCount; i++ {
		userIDs[i] = "user" + keyPrefix + string(rune('A'+i%26))
	}

	for i := 0; i < ipCount; i++ {
		ipAddrs[i] = "192.168.1." + string(rune('1'+i%254))
	}

	b.Run("UserRateLimiter", func(b *testing.B) {
		b.ResetTimer()
		b.RunParallel(func(pb *testing.PB) {
			rnd := rand.New(rand.NewSource(time.Now().UnixNano()))
			for pb.Next() {
				userID := userIDs[rnd.Intn(userCount)]
				userLimiter.AllowUser(userID)
			}
		})
	})

	b.Run("IPRateLimiter", func(b *testing.B) {
		b.ResetTimer()
		b.RunParallel(func(pb *testing.PB) {
			rnd := rand.New(rand.NewSource(time.Now().UnixNano()))
			for pb.Next() {
				ip := ipAddrs[rnd.Intn(ipCount)]
				ipLimiter.AllowIP(ip)
			}
		})
	})

	// 清理测试数据
	for _, userID := range userIDs {
		redisClient.Del(ctx, "ratelimit:user:"+userID)
	}
	for _, ip := range ipAddrs {
		redisClient.Del(ctx, "ratelimit:ip:"+ip)
	}
}

// BenchmarkAdaptiveBreaker 基准测试自适应熔断器性能
func BenchmarkAdaptiveBreaker(b *testing.B) {
	// 创建自适应熔断器
	adaptiveBreaker := breaker.NewAdaptiveBreaker(
		breaker.WithErrorThreshold(0.5),           // 50%错误率触发熔断
		breaker.WithRecoveryWindow(2*time.Second), // 2秒后尝试恢复
		breaker.WithRecoveryRate(0.2),             // 恢复期间允许20%请求通过
	)

	// 错误率为10%
	errorRate := 0.1

	b.Run("Execute", func(b *testing.B) {
		b.ResetTimer()
		b.RunParallel(func(pb *testing.PB) {
			rnd := rand.New(rand.NewSource(time.Now().UnixNano()))
			for pb.Next() {
				adaptiveBreaker.Execute(func() error {
					// 随机生成错误
					if rnd.Float64() < errorRate {
						return errors.New("模拟错误")
					}
					return nil
				})
			}
		})
	})

	// 重置熔断器状态
	adaptiveBreaker.Reset()

	b.Run("ExecuteWithResult", func(b *testing.B) {
		// 注册降级函数
		adaptiveBreaker.RegisterFallback("benchmark", func(err error) (interface{}, error) {
			return "降级响应", nil
		})

		b.ResetTimer()
		b.RunParallel(func(pb *testing.PB) {
			rnd := rand.New(rand.NewSource(time.Now().UnixNano()))
			for pb.Next() {
				adaptiveBreaker.ExecuteWithResult(context.Background(), "benchmark", func() (interface{}, error) {
					// 随机生成错误
					if rnd.Float64() < errorRate {
						return nil, errors.New("模拟错误")
					}
					return "正常响应", nil
				})
			}
		})
	})
}
