package tests

import (
	"context"
	"fmt"
	"os"
	"sync"
	"testing"
	"time"

	"github.com/ammyhaber/seckill/config"
	"github.com/ammyhaber/seckill/service/inventory/cache"
	invdao "github.com/ammyhaber/seckill/service/inventory/dao"
	invservice "github.com/ammyhaber/seckill/service/inventory/service"
	"github.com/go-redis/redis/v8"
	_ "github.com/go-sql-driver/mysql"
	"github.com/jmoiron/sqlx"
)

// 全局变量
var (
	db           *sqlx.DB
	redisClient  *redis.Client
	inventoryDAO *invdao.InventoryDAO
	redisCache   *cache.RedisCache
	invService   *invservice.InventoryService
)

// init 函数在测试开始前执行
func init() {
	// 设置配置文件路径
	os.Setenv("CONFIG_FILE", "../../config/config_test.json")
}

// TestMain 测试主函数
func TestMain(m *testing.M) {
	// 初始化测试环境
	setupBenchmarkTest()

	// 运行测试
	code := m.Run()

	// 清理测试环境
	teardownBenchmarkTest()

	os.Exit(code)
}

// BenchmarkSeckill 秒杀性能测试
func BenchmarkSeckill(b *testing.B) {
	// 跳过正常测试
	if testing.Short() {
		b.Skip("跳过秒杀性能测试")
	}

	// 商品ID
	productID := int64(10001)
	// 购买数量
	count := 1

	// 准备测试数据
	prepareBenchmarkData(productID, 10000) // 准备10000个库存用于基准测试

	// 重置计数器
	b.ResetTimer()

	// 并发测试
	b.RunParallel(func(pb *testing.PB) {
		for pb.Next() {
			// 创建上下文
			ctx := context.Background()
			// 尝试扣减库存
			success, err := invService.DecrInventory(ctx, productID, count)
			if err != nil {
				// 忽略库存不足错误
				continue
			}
			if success {
				// 模拟订单处理
				time.Sleep(10 * time.Millisecond)
				// 确认扣减
				_ = invService.ConfirmDeduction(ctx, productID, count)
			}
		}
	})
}

// TestConcurrentSeckill 并发秒杀测试
func TestConcurrentSeckill(t *testing.T) {
	// 设置并发数
	concurrency := 100
	// 商品ID
	productID := int64(10001)
	// 购买数量
	count := 1
	// 总库存
	totalStock := 50

	// 准备测试数据
	prepareBenchmarkData(productID, totalStock)

	// 等待组
	var wg sync.WaitGroup
	// 成功计数
	successCount := 0
	// 互斥锁
	var mu sync.Mutex

	// 添加超时控制
	testCtx, cancel := context.WithTimeout(context.Background(), 30*time.Second)
	defer cancel() // 确保资源释放

	// 启动并发请求
	for i := 0; i < concurrency; i++ {
		wg.Add(1)
		go func(idx int) {
			defer wg.Done()

			// 使用带超时的上下文
			success, err := invService.DecrInventory(testCtx, productID, count)
			if err != nil {
				return
			}
			if success {
				// 模拟订单处理
				select {
				case <-testCtx.Done():
					// 上下文取消，不进行后续操作
					return
				case <-time.After(10 * time.Millisecond):
					// 继续处理
				}

				// 确认扣减
				err = invService.ConfirmDeduction(testCtx, productID, count)
				if err == nil {
					mu.Lock()
					successCount++
					mu.Unlock()
				}
			}
		}(i)
	}

	// 等待所有请求完成
	wg.Wait()

	// 验证结果
	t.Logf("并发数: %d, 总库存: %d, 成功下单: %d", concurrency, totalStock, successCount)

	// 检查是否有超卖
	if successCount > totalStock {
		t.Errorf("发生超卖! 总库存: %d, 成功下单: %d", totalStock, successCount)
	}

	// 检查最终库存
	ctx := context.Background()
	detail, _ := invService.GetInventoryDetail(ctx, productID)
	expectedAvailable := totalStock - successCount
	if detail.Available != expectedAvailable || detail.Locked != 0 {
		t.Errorf("库存数据不匹配，期望可用库存: %d, 实际可用库存: %d, 锁定库存: %d",
			expectedAvailable, detail.Available, detail.Locked)
	}
}

// prepareBenchmarkData 准备基准测试数据
func prepareBenchmarkData(productID int64, stock int) {
	// 清理旧数据
	db.MustExec("DELETE FROM inventory WHERE product_id = ?", productID)
	db.MustExec("DELETE FROM product WHERE id = ?", productID)

	// 插入测试商品
	db.MustExec("INSERT INTO product (id, name, description, price, stock, status) VALUES (?, '基准测试商品', '性能测试商品', 9.99, ?, 1)",
		productID, stock)

	// 插入测试库存
	db.MustExec("INSERT INTO inventory (product_id, total, available, locked, version) VALUES (?, ?, ?, 0, 0)",
		productID, stock, stock)

	// 初始化Redis缓存
	ctx := context.Background()
	invService.InitCache(ctx)
}

// setupBenchmarkTest 初始化性能测试环境
func setupBenchmarkTest() {
	// 获取配置
	cfg := config.GetConfig()

	fmt.Printf("使用数据库地址: %s:%d\n", cfg.MySQL.Host, cfg.MySQL.Port)

	// 初始化数据库连接
	dsn := fmt.Sprintf("%s:%s@tcp(%s:%d)/%s?%s",
		cfg.MySQL.Username,
		cfg.MySQL.Password,
		cfg.MySQL.Host,
		cfg.MySQL.Port,
		cfg.MySQL.Database,
		cfg.MySQL.Params)

	var err error
	db, err = sqlx.Connect("mysql", dsn)
	if err != nil {
		panic(fmt.Sprintf("连接数据库失败: %v", err))
	}

	// 设置连接池参数 - 增加连接数以支持高并发测试
	db.SetMaxIdleConns(50)
	db.SetMaxOpenConns(200)
	db.SetConnMaxLifetime(time.Hour)

	// 初始化Redis客户端
	redisClient = redis.NewClient(&redis.Options{
		Addr:         fmt.Sprintf("%s:%d", cfg.Redis.Host, cfg.Redis.Port),
		Password:     cfg.Redis.Password,
		DB:           cfg.Redis.DB,
		PoolSize:     200, // 增加连接池大小以支持高并发
		MinIdleConns: 50,
		DialTimeout:  cfg.Redis.DialTimeout,
		ReadTimeout:  cfg.Redis.ReadTimeout,
		WriteTimeout: cfg.Redis.WriteTimeout,
	})

	// 初始化各层组件
	inventoryDAO = invdao.NewInventoryDAO(db)
	redisCache = cache.NewRedisCache(redisClient)
	invService = invservice.NewInventoryService(inventoryDAO, redisCache)
}

// teardownBenchmarkTest 清理性能测试环境
func teardownBenchmarkTest() {
	// 清理测试数据
	db.MustExec("DELETE FROM inventory WHERE product_id = 10001")
	db.MustExec("DELETE FROM product WHERE id = 10001")

	// 清理Redis缓存
	ctx := context.Background()
	redisClient.Del(ctx, "seckill:inventory:10001")

	// 关闭连接
	if db != nil {
		db.Close()
	}
	if redisClient != nil {
		redisClient.Close()
	}
}
