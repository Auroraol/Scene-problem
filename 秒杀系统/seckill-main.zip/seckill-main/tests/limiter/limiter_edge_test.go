package limiter

import (
	"context"
	"testing"
	"time"

	"github.com/ammyhaber/seckill/pkg/limiter"
	"github.com/go-redis/redis/v8"
)

// setupLimiterRedisClient 创建测试用Redis客户端
func setupLimiterRedisClient() *redis.Client {
	return redis.NewClient(&redis.Options{
		Addr:     "localhost:6379",
		Password: "",
		DB:       0,
	})
}

// TestTokenBucketEdgeCases 测试令牌桶限流器的边缘情况
func TestTokenBucketEdgeCases(t *testing.T) {
	t.Run("ZeroRate", func(t *testing.T) {
		// 测试生成速率为0的情况
		limiter := limiter.NewTokenBucket(0, 10)

		// 初始应该有10个令牌
		for i := 0; i < 10; i++ {
			if !limiter.Allow() {
				t.Errorf("第%d个请求应该通过但被拒绝", i+1)
			}
		}

		// 第11个请求应该被拒绝
		if limiter.Allow() {
			t.Error("第11个请求应该被拒绝但通过了")
		}

		// 等待一段时间后，由于生成速率为0，仍应该没有新令牌
		time.Sleep(1 * time.Second)
		if limiter.Allow() {
			t.Error("等待后仍应拒绝请求，但通过了")
		}
	})

	t.Run("ZeroCapacity", func(t *testing.T) {
		// 测试容量为0的情况
		limiter := limiter.NewTokenBucket(5, 0)

		// 由于容量为0，初始没有令牌，第一个请求应该被拒绝
		if limiter.Allow() {
			t.Error("第1个请求应该被拒绝但通过了")
		}

		// 等待足够时间生成一些令牌
		time.Sleep(1 * time.Second)

		// 现在应该允许一些请求通过
		passCount := 0
		for i := 0; i < 10; i++ {
			if limiter.Allow() {
				passCount++
			}
		}

		// 验证通过的请求数量应该约为生成速率
		t.Logf("1秒后通过请求数: %d", passCount)
		if passCount < 3 || passCount > 7 {
			t.Errorf("通过请求数不符合预期，期望约为5，实际为%d", passCount)
		}
	})

	t.Run("HighRate", func(t *testing.T) {
		// 测试极高生成速率的情况
		limiter := limiter.NewTokenBucket(10000, 100)

		// 先消耗所有初始令牌
		for i := 0; i < 100; i++ {
			limiter.Allow()
		}

		// 等待非常短的时间
		time.Sleep(10 * time.Millisecond)

		// 即使等待时间很短，也应该生成了约100个新令牌
		passCount := 0
		for i := 0; i < 200; i++ {
			if limiter.Allow() {
				passCount++
			}
		}

		t.Logf("10ms后通过请求数: %d", passCount)
		if passCount < 80 {
			t.Errorf("通过请求数不符合预期，期望约为100，实际为%d", passCount)
		}
	})
}

// TestRedisRateLimiterEdgeCases 测试Redis分布式限流器的边缘情况
func TestRedisRateLimiterEdgeCases(t *testing.T) {
	ctx := context.Background()
	redisClient := setupLimiterRedisClient()

	// 测试Redis连接
	_, err := redisClient.Ping(ctx).Result()
	if err != nil {
		t.Skip("Redis不可用，跳过分布式限流测试")
	}

	t.Run("ZeroLimit", func(t *testing.T) {
		// 测试限制为0的情况
		keyPrefix := "test:zero:" + time.Now().Format("20060102150405")
		zeroLimiter := limiter.NewRedisRateLimiter(redisClient, keyPrefix, 0, 10*time.Second)

		// 所有请求都应该被拒绝
		if zeroLimiter.Allow() {
			t.Error("请求应该被拒绝但通过了")
		}

		// 清理测试数据
		redisClient.Del(ctx, keyPrefix+":global")
	})

	t.Run("ZeroWindow", func(t *testing.T) {
		// 测试窗口为0的情况
		keyPrefix := "test:zerowindow:" + time.Now().Format("20060102150405")
		zeroWindowLimiter := limiter.NewRedisRateLimiter(redisClient, keyPrefix, 5, 0)

		// 前5个请求应该通过
		for i := 0; i < 5; i++ {
			if !zeroWindowLimiter.Allow() {
				t.Errorf("第%d个请求应该通过但被拒绝", i+1)
			}
		}

		// 第6个请求应该被拒绝
		if zeroWindowLimiter.Allow() {
			t.Error("第6个请求应该被拒绝但通过了")
		}

		// 清理测试数据
		redisClient.Del(ctx, keyPrefix+":global")
	})

	t.Run("NegativeValues", func(t *testing.T) {
		// 测试负值输入的情况
		keyPrefix := "test:negative:" + time.Now().Format("20060102150405")
		negativeLimiter := limiter.NewRedisRateLimiter(redisClient, keyPrefix, -5, -10*time.Second)

		// 由于输入无效，应该默认为严格限流
		if negativeLimiter.Allow() {
			t.Error("请求应该被拒绝但通过了")
		}

		// 清理测试数据
		redisClient.Del(ctx, keyPrefix+":global")
	})
}

// TestUserIPRateLimiterEdgeCases 测试用户和IP限流器的边缘情况
func TestUserIPRateLimiterEdgeCases(t *testing.T) {
	ctx := context.Background()
	redisClient := setupLimiterRedisClient()

	// 测试Redis连接
	_, err := redisClient.Ping(ctx).Result()
	if err != nil {
		t.Skip("Redis不可用，跳过用户IP限流测试")
	}

	t.Run("EmptyUser", func(t *testing.T) {
		// 测试空用户ID
		userLimiter := limiter.NewUserRateLimiter(redisClient, 3, 10*time.Second)

		// 空用户ID应该被当作特殊情况处理
		for i := 0; i < 3; i++ {
			if !userLimiter.AllowUser("") {
				t.Errorf("空用户第%d个请求应该通过但被拒绝", i+1)
			}
		}

		// 第4个请求应该被拒绝
		if userLimiter.AllowUser("") {
			t.Error("空用户第4个请求应该被拒绝但通过了")
		}

		// 清理测试数据
		redisClient.Del(ctx, "ratelimit:user:")
	})

	t.Run("EmptyIP", func(t *testing.T) {
		// 测试空IP地址
		ipLimiter := limiter.NewIPRateLimiter(redisClient, 3, 10*time.Second)

		// 空IP应该被当作特殊情况处理
		for i := 0; i < 3; i++ {
			if !ipLimiter.AllowIP("") {
				t.Errorf("空IP第%d个请求应该通过但被拒绝", i+1)
			}
		}

		// 第4个请求应该被拒绝
		if ipLimiter.AllowIP("") {
			t.Error("空IP第4个请求应该被拒绝但通过了")
		}

		// 清理测试数据
		redisClient.Del(ctx, "ratelimit:ip:")
	})

	t.Run("SpecialCharacters", func(t *testing.T) {
		// 测试包含特殊字符的用户ID和IP
		userLimiter := limiter.NewUserRateLimiter(redisClient, 3, 10*time.Second)
		ipLimiter := limiter.NewIPRateLimiter(redisClient, 3, 10*time.Second)

		specialUser := "user:with:colons"
		specialIP := "192.168.1.1:8080"

		// 特殊字符应该被正确处理
		for i := 0; i < 3; i++ {
			if !userLimiter.AllowUser(specialUser) {
				t.Errorf("特殊用户第%d个请求应该通过但被拒绝", i+1)
			}
			if !ipLimiter.AllowIP(specialIP) {
				t.Errorf("特殊IP第%d个请求应该通过但被拒绝", i+1)
			}
		}

		// 第4个请求应该被拒绝
		if userLimiter.AllowUser(specialUser) {
			t.Error("特殊用户第4个请求应该被拒绝但通过了")
		}
		if ipLimiter.AllowIP(specialIP) {
			t.Error("特殊IP第4个请求应该被拒绝但通过了")
		}

		// 清理测试数据
		redisClient.Del(ctx, "ratelimit:user:"+specialUser)
		redisClient.Del(ctx, "ratelimit:ip:"+specialIP)
	})
}

// TestMultiLimiterCombination 测试多个限流器组合使用的情况
func TestMultiLimiterCombination(t *testing.T) {
	ctx := context.Background()
	redisClient := setupLimiterRedisClient()

	// 测试Redis连接
	_, err := redisClient.Ping(ctx).Result()
	if err != nil {
		t.Skip("Redis不可用，跳过多限流器组合测试")
	}

	// 创建全局限流器
	globalLimiter := limiter.NewTokenBucket(10, 10)

	// 创建用户限流器
	userLimiter := limiter.NewUserRateLimiter(redisClient, 5, 10*time.Second)

	// 创建IP限流器
	ipLimiter := limiter.NewIPRateLimiter(redisClient, 5, 10*time.Second)

	// 清理之前可能存在的数据
	testUser := "test_combo_user"
	testIP := "192.168.1.100"
	redisClient.Del(ctx, "ratelimit:user:"+testUser)
	redisClient.Del(ctx, "ratelimit:ip:"+testIP)

	// 测试组合限流
	for i := 0; i < 15; i++ {
		// 全局限流
		isGlobalAllowed := globalLimiter.Allow()
		// 用户限流
		isUserAllowed := userLimiter.AllowUser(testUser)
		// IP限流
		isIPAllowed := ipLimiter.AllowIP(testIP)

		// 只有三个限流器都允许时才通过
		isAllowed := isGlobalAllowed && isUserAllowed && isIPAllowed

		if i < 5 {
			// 前5个请求应该通过全部限流器
			if !isAllowed {
				t.Errorf("请求%d应该通过所有限流器，但被拒绝，状态：全局=%v, 用户=%v, IP=%v",
					i+1, isGlobalAllowed, isUserAllowed, isIPAllowed)
			}
		} else if i >= 10 {
			// 第11个以后的请求应该被全局限流器拒绝
			if isGlobalAllowed {
				t.Errorf("请求%d应该被全局限流器拒绝，但通过了", i+1)
			}
		} else {
			// 第6-10个请求应该被用户和IP限流器拒绝，但允许通过全局限流器
			if !isGlobalAllowed {
				t.Errorf("请求%d应该通过全局限流器，但被拒绝", i+1)
			}
			if isUserAllowed {
				t.Errorf("请求%d应该被用户限流器拒绝，但通过了", i+1)
			}
			if isIPAllowed {
				t.Errorf("请求%d应该被IP限流器拒绝，但通过了", i+1)
			}
		}
	}

	// 清理测试数据
	redisClient.Del(ctx, "ratelimit:user:"+testUser)
	redisClient.Del(ctx, "ratelimit:ip:"+testIP)
}
