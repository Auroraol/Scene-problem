package httpclient

import (
	"context"
	"encoding/json"
	"io/ioutil"
	"net/http"
	"net/http/httptest"
	"strings"
	"testing"
	"time"

	"github.com/ammyhaber/seckill/pkg/httpclient"
)

// TestHTTPClientBasic 测试HTTP客户端基本功能
func TestHTTPClientBasic(t *testing.T) {
	// 创建测试服务器
	server := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		// 简单响应
		w.Header().Set("Content-Type", "application/json")
		w.WriteHeader(http.StatusOK)
		w.Write([]byte(`{"code": 200, "msg": "OK", "data": null}`))
	}))
	defer server.Close()

	// 创建HTTP客户端
	client := httpclient.NewHttpClient(server.URL, 5*time.Second, 3)

	// 发送GET请求
	ctx := context.Background()
	resp, err := client.Get(ctx, "/test", nil)
	if err != nil {
		t.Fatalf("发送GET请求失败: %v", err)
	}

	// 验证响应
	if resp.Code != 200 {
		t.Errorf("响应状态码不正确，期望: %d, 实际: %d", 200, resp.Code)
	}

	if resp.Msg != "OK" {
		t.Errorf("响应消息不正确，期望: %s, 实际: %s", "OK", resp.Msg)
	}
}

// TestHTTPClientTimeout 测试HTTP客户端超时功能
func TestHTTPClientTimeout(t *testing.T) {
	// 创建测试服务器，延迟2秒响应
	server := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		time.Sleep(2 * time.Second)
		w.Header().Set("Content-Type", "application/json")
		w.WriteHeader(http.StatusOK)
		w.Write([]byte(`{"code": 200, "msg": "OK"}`))
	}))
	defer server.Close()

	// 创建HTTP客户端，超时时间1秒
	client := httpclient.NewHttpClient(server.URL, 1*time.Second, 1)

	// 发送GET请求
	ctx := context.Background()
	_, err := client.Get(ctx, "/test", nil)

	// 验证是否超时
	if err == nil {
		t.Fatal("期望请求超时，但请求成功")
	}

	// 检查错误是否包含超时相关信息
	errMsg := err.Error()
	if !strings.Contains(errMsg, "context deadline exceeded") &&
		!strings.Contains(errMsg, "deadline exceeded") &&
		!strings.Contains(errMsg, "Timeout exceeded") &&
		!strings.Contains(errMsg, "Client.Timeout exceeded") {
		t.Errorf("期望超时错误，实际错误: %v", err)
	}
}

// isTimeoutError 检查错误是否为超时错误
func isTimeoutError(err error) bool {
	if err == nil {
		return false
	}
	errMsg := err.Error()
	return strings.Contains(errMsg, "context deadline exceeded") ||
		strings.Contains(errMsg, "deadline exceeded") ||
		strings.Contains(errMsg, "Timeout exceeded") ||
		strings.Contains(errMsg, "Client.Timeout exceeded")
}

// TestHTTPClientRetry 测试HTTP客户端重试功能
func TestHTTPClientRetry(t *testing.T) {
	// 记录请求次数
	requestCount := 0

	// 创建一个可关闭的服务器，模拟连接失败
	server := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		requestCount++
		if requestCount < 3 {
			// 模拟连接关闭或网络错误，直接关闭连接而不返回响应
			hj, ok := w.(http.Hijacker)
			if !ok {
				t.Fatalf("不支持http.Hijacker")
			}
			conn, _, err := hj.Hijack()
			if err != nil {
				t.Fatalf("Hijack失败: %v", err)
			}
			conn.Close() // 直接关闭连接
			return
		}
		// 第三次请求成功
		w.Header().Set("Content-Type", "application/json")
		w.WriteHeader(http.StatusOK)
		w.Write([]byte(`{"code": 200, "msg": "成功"}`))
	}))
	defer server.Close()

	// 创建HTTP客户端，设置最大重试次数为3，超时设置较短以便快速发现错误
	client := httpclient.NewHttpClient(server.URL, 1*time.Second, 3)

	// 发送GET请求
	ctx := context.Background()
	resp, err := client.Get(ctx, "/test", nil)
	if err != nil {
		t.Fatalf("发送GET请求失败: %v", err)
	}

	// 验证响应是否成功
	if resp.Code != 200 {
		t.Errorf("响应状态码不正确，期望: %d, 实际: %d", 200, resp.Code)
	}

	// 验证请求次数
	if requestCount != 3 {
		t.Errorf("重试次数不正确，期望: %d, 实际: %d", 3, requestCount)
	}
}

// 替代方案：另一种测试重试功能的方法（通过模拟网络错误）
func TestHTTPClientRetryWithNetError(t *testing.T) {
	// 如果上面的测试方法在某些环境中不可靠，可以使用此测试方法
	t.Skip("这是一个备用测试方法，当前未使用")

	// 1. 启动一个服务器
	// 2. 处理第一个请求后关闭服务器
	// 3. 启动一个新服务器监听相同端口
	// 4. 处理第二个请求后关闭服务器
	// 5. 启动第三个服务器处理最终请求
}

// TestHTTPClientPost 测试HTTP客户端POST请求
func TestHTTPClientPost(t *testing.T) {
	// 创建测试服务器
	server := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		// 验证请求方法
		if r.Method != "POST" {
			t.Errorf("请求方法不正确，期望: %s, 实际: %s", "POST", r.Method)
		}

		// 验证内容类型
		contentType := r.Header.Get("Content-Type")
		if contentType != "application/json" {
			t.Errorf("内容类型不正确，期望: %s, 实际: %s", "application/json", contentType)
		}

		// 读取请求体
		body, err := ioutil.ReadAll(r.Body)
		if err != nil {
			t.Fatalf("读取请求体失败: %v", err)
		}

		// 验证请求数据
		var data map[string]interface{}
		if err := json.Unmarshal(body, &data); err != nil {
			t.Fatalf("解析请求体失败: %v", err)
		}

		// 响应
		w.Header().Set("Content-Type", "application/json")
		w.WriteHeader(http.StatusCreated)
		w.Write([]byte(`{"code": 201, "msg": "Created", "data": {"success": true}}`))
	}))
	defer server.Close()

	// 创建HTTP客户端
	client := httpclient.NewHttpClient(server.URL, 5*time.Second, 3)

	// 发送POST请求
	ctx := context.Background()
	reqData := map[string]interface{}{
		"name":  "test",
		"value": 123,
	}
	resp, err := client.Post(ctx, "/api/data", reqData)
	if err != nil {
		t.Fatalf("发送POST请求失败: %v", err)
	}

	// 验证响应状态码
	if resp.Code != 201 {
		t.Errorf("响应状态码不正确，期望: %d, 实际: %d", 201, resp.Code)
	}

	// 验证响应消息
	if resp.Msg != "Created" {
		t.Errorf("响应消息不正确，期望: %s, 实际: %s", "Created", resp.Msg)
	}

	// 验证响应数据
	var respData map[string]interface{}
	if err := json.Unmarshal(resp.Data, &respData); err != nil {
		t.Fatalf("解析响应数据失败: %v", err)
	}

	success, ok := respData["success"]
	if !ok || success != true {
		t.Errorf("响应数据不正确，期望: {\"success\": true}, 实际: %s", string(resp.Data))
	}
}

// TestHTTPClientRawResponse 测试获取原始HTTP响应功能
func TestHTTPClientRawResponse(t *testing.T) {
	// 由于当前的HttpClient实现没有提供访问原始HTTP响应的接口，此测试暂时跳过
	t.Skip("HttpClient当前不支持获取原始HTTP响应，需要未来扩展此功能")
}
