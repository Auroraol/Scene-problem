package middleware

import (
	"context"
	"fmt"
	"net/http"
	"net/http/httptest"
	"strings"
	"testing"
	"time"

	"github.com/ammyhaber/seckill/pkg/breaker"
	"github.com/ammyhaber/seckill/pkg/limiter"
	"github.com/ammyhaber/seckill/pkg/metrics"
	ordermiddleware "github.com/ammyhaber/seckill/service/order/middleware"
	"github.com/go-redis/redis/v8"
)

// setupRecoveryRedisClient 创建Redis客户端
func setupRecoveryRedisClient() *redis.Client {
	return redis.NewClient(&redis.Options{
		Addr:     "localhost:6379",
		Password: "",
		DB:       0,
	})
}

// TestPanicRecoveryMiddleware 测试中间件的异常恢复功能
func TestPanicRecoveryMiddleware(t *testing.T) {
	// 创建一个会引发panic的处理函数
	panicHandler := http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		panic("测试异常")
	})

	// 使用恢复中间件包装处理函数
	recoveryHandler := ordermiddleware.RecoveryMiddleware()(panicHandler)

	// 创建HTTP请求和记录响应的recorder
	req := httptest.NewRequest("GET", "http://example.com/test", nil)
	w := httptest.NewRecorder()

	// 执行请求，应该会捕获panic而不崩溃
	recoveryHandler.ServeHTTP(w, req)

	// 验证响应状态码是否为500
	if w.Code != http.StatusInternalServerError {
		t.Errorf("期望状态码%d，实际为%d", http.StatusInternalServerError, w.Code)
	}

	// 验证响应内容是否包含适当的错误信息
	if !strings.Contains(w.Body.String(), "系统错误") {
		t.Errorf("期望响应包含错误信息，实际为：%s", w.Body.String())
	}
}

// TestCombinedMiddleware 测试中间件组合
func TestCombinedMiddleware(t *testing.T) {
	// 创建一个正常的处理函数
	normalHandler := http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		// 从上下文中获取键值
		if value := r.Context().Value("test_key"); value != "test_value" {
			t.Errorf("上下文键值不匹配，期望:%s，实际:%v", "test_value", value)
		}
		w.WriteHeader(http.StatusOK)
		w.Write([]byte("OK"))
	})

	// 创建一个添加上下文的中间件
	contextMiddleware := func(next http.Handler) http.Handler {
		return http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
			ctx := context.WithValue(r.Context(), "test_key", "test_value")
			next.ServeHTTP(w, r.WithContext(ctx))
		})
	}

	// 创建限流器
	rateLimiter := limiter.NewTokenBucket(5, 5)

	// 创建熔断器
	adaptiveBreaker := breaker.NewAdaptiveBreaker()

	// 创建指标收集器
	redisClient := setupRecoveryRedisClient()
	metricsCollector := metrics.NewMetricsCollector(redisClient, "test:metrics", 10*time.Second)
	breakerMetrics := metrics.NewBreakerMetrics(metricsCollector, "test_breaker")

	// 组合多个中间件
	handler := ordermiddleware.RecoveryMiddleware()(
		ordermiddleware.LoggingMiddleware()(
			contextMiddleware(
				ordermiddleware.RateLimiterMiddleware(rateLimiter)(
					ordermiddleware.AdaptiveBreakerMiddleware(adaptiveBreaker, "test", breakerMetrics)(
						normalHandler,
					),
				),
			),
		),
	)

	// 创建HTTP请求和记录响应的recorder
	req := httptest.NewRequest("GET", "http://example.com/test", nil)
	w := httptest.NewRecorder()

	// 执行请求
	handler.ServeHTTP(w, req)

	// 验证响应状态码是否为200
	if w.Code != http.StatusOK {
		t.Errorf("期望状态码%d，实际为%d", http.StatusOK, w.Code)
	}

	// 验证响应内容
	if w.Body.String() != "OK" {
		t.Errorf("期望响应为:%s，实际为:%s", "OK", w.Body.String())
	}
}

// TestMiddlewareOrder 测试中间件执行顺序
func TestMiddlewareOrder(t *testing.T) {
	// 创建一个通道来记录执行顺序
	order := make(chan string, 10)

	// 创建一个最终的处理函数
	finalHandler := http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		order <- "handler"
		w.WriteHeader(http.StatusOK)
	})

	// 创建多个中间件，每个都记录自己的执行顺序
	middleware1 := func(next http.Handler) http.Handler {
		return http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
			order <- "middleware1_before"
			next.ServeHTTP(w, r)
			order <- "middleware1_after"
		})
	}

	middleware2 := func(next http.Handler) http.Handler {
		return http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
			order <- "middleware2_before"
			next.ServeHTTP(w, r)
			order <- "middleware2_after"
		})
	}

	middleware3 := func(next http.Handler) http.Handler {
		return http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
			order <- "middleware3_before"
			next.ServeHTTP(w, r)
			order <- "middleware3_after"
		})
	}

	// 组合中间件
	handler := middleware1(middleware2(middleware3(finalHandler)))

	// 创建HTTP请求和记录响应的recorder
	req := httptest.NewRequest("GET", "http://example.com/test", nil)
	w := httptest.NewRecorder()

	// 执行请求
	handler.ServeHTTP(w, req)

	// 关闭通道
	close(order)

	// 收集执行顺序
	var executionOrder []string
	for o := range order {
		executionOrder = append(executionOrder, o)
	}

	// 验证执行顺序
	expected := []string{
		"middleware1_before",
		"middleware2_before",
		"middleware3_before",
		"handler",
		"middleware3_after",
		"middleware2_after",
		"middleware1_after",
	}

	// 比较执行顺序
	if len(executionOrder) != len(expected) {
		t.Fatalf("执行顺序长度不匹配，期望:%d，实际:%d", len(expected), len(executionOrder))
	}

	for i, item := range expected {
		if executionOrder[i] != item {
			t.Errorf("执行顺序第%d位不匹配，期望:%s，实际:%s", i+1, item, executionOrder[i])
		}
	}
}

// TestRequestContextTimeout 测试请求上下文超时
func TestRequestContextTimeout(t *testing.T) {
	// 创建一个会延迟响应的处理函数
	delayHandler := http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		// 检查上下文是否会被取消
		select {
		case <-r.Context().Done():
			// 上下文被取消，但我们仍然可以写入响应
			w.WriteHeader(http.StatusGatewayTimeout)
			w.Write([]byte("请求超时"))
			return
		case <-time.After(500 * time.Millisecond):
			// 正常处理
			w.WriteHeader(http.StatusOK)
			w.Write([]byte("OK"))
		}
	})

	// 使用超时中间件包装处理函数
	timeoutMiddleware := func(next http.Handler) http.Handler {
		return http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
			// 创建一个100毫秒超时的上下文
			ctx, cancel := context.WithTimeout(r.Context(), 100*time.Millisecond)
			defer cancel()

			// 使用新上下文创建新请求
			r = r.WithContext(ctx)

			// 创建一个响应写入器包装器，用于捕获状态码
			wrapped := ordermiddleware.NewResponseWriterWrapper(w)

			// 使用自定义的响应写入器调用下一个处理函数
			done := make(chan struct{})
			go func() {
				next.ServeHTTP(wrapped, r)
				close(done)
			}()

			select {
			case <-ctx.Done():
				if ctx.Err() == context.DeadlineExceeded {
					// 如果还没有写入响应，写入超时状态
					if wrapped.Status == 0 {
						wrapped.WriteHeader(http.StatusGatewayTimeout)
						wrapped.Write([]byte("请求处理超时"))
					}
				}
			case <-done:
				// 处理函数已完成
			}
		})
	}

	// 使用超时中间件包装处理函数
	timeoutHandler := timeoutMiddleware(delayHandler)

	// 创建HTTP请求和记录响应的recorder
	req := httptest.NewRequest("GET", "http://example.com/test", nil)
	w := httptest.NewRecorder()

	// 执行请求
	timeoutHandler.ServeHTTP(w, req)

	// 验证响应状态码是否为504（超时）
	if w.Code != http.StatusGatewayTimeout {
		t.Errorf("期望状态码%d，实际为%d", http.StatusGatewayTimeout, w.Code)
	}
}

// TestBreakerMetricsMiddleware 测试熔断器指标中间件
func TestBreakerMetricsMiddleware(t *testing.T) {
	ctx := context.Background()
	redisClient := setupRecoveryRedisClient()

	// 测试Redis连接
	_, err := redisClient.Ping(ctx).Result()
	if err != nil {
		t.Skip("Redis不可用，跳过熔断器指标测试")
	}

	// 创建指标收集器
	metricsCollector := metrics.NewMetricsCollector(redisClient, "test:metrics", 10*time.Second)

	// 创建熔断器指标
	breakerMetrics := metrics.NewBreakerMetrics(metricsCollector, "test_breaker")

	// 创建熔断器
	adaptiveBreaker := breaker.NewAdaptiveBreaker(
		breaker.WithErrorThreshold(0.5),
		breaker.WithRecoveryWindow(1*time.Second),
	)

	// 创建处理函数
	successCount := 0
	handler := http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		successCount++
		if successCount <= 5 {
			// 前5个请求成功
			w.WriteHeader(http.StatusOK)
			w.Write([]byte(fmt.Sprintf("成功请求 %d", successCount)))
		} else {
			// 之后的请求触发服务器错误
			w.WriteHeader(http.StatusInternalServerError)
			w.Write([]byte(fmt.Sprintf("错误请求 %d", successCount-5)))
		}
	})

	// 应用熔断器中间件
	breakerHandler := ordermiddleware.AdaptiveBreakerMiddleware(adaptiveBreaker, "test_endpoint", breakerMetrics)(handler)

	// 发送一批请求，前5个成功，后5个失败
	for i := 1; i <= 10; i++ {
		req := httptest.NewRequest("GET", "http://example.com/test", nil)
		w := httptest.NewRecorder()
		breakerHandler.ServeHTTP(w, req)

		// 记录状态码
		t.Logf("请求 %d 状态码: %d", i, w.Code)
	}

	// 等待一小段时间让指标更新
	time.Sleep(100 * time.Millisecond)

	// 清理测试数据
	// metricsCollector.Clear(ctx, "test_breaker:test_endpoint")
}
