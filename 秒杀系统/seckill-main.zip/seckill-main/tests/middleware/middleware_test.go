package middleware

import (
	"context"
	"errors"
	"net/http"
	"net/http/httptest"
	"sync"
	"sync/atomic"
	"testing"
	"time"

	"github.com/ammyhaber/seckill/pkg/breaker"
	"github.com/ammyhaber/seckill/pkg/limiter"
	"github.com/ammyhaber/seckill/pkg/metrics"
	middleware "github.com/ammyhaber/seckill/service/order/middleware"
	"github.com/go-redis/redis/v8"
	"github.com/stretchr/testify/assert"
)

func setupRedisClient() *redis.Client {
	return redis.NewClient(&redis.Options{
		Addr:     "localhost:6379",
		Password: "",
		DB:       0,
	})
}

// TestTokenBucketLimiter 测试令牌桶限流器
func TestTokenBucketLimiter(t *testing.T) {
	// 创建令牌桶限流器，每秒5个请求，最多积累10个令牌
	limiter := limiter.NewTokenBucket(5, 10)

	// 测试初始允许10个请求通过
	for i := 0; i < 10; i++ {
		assert.True(t, limiter.Allow(), "应该允许请求通过")
	}

	// 测试第11个请求被拦截
	assert.False(t, limiter.Allow(), "应该拦截请求")

	// 等待一段时间后，应该允许新的请求通过
	time.Sleep(1 * time.Second)
	// 1秒后应该生成了5个新令牌
	for i := 0; i < 5; i++ {
		assert.True(t, limiter.Allow(), "等待后应该允许请求通过")
	}
	assert.False(t, limiter.Allow(), "应该拦截多余请求")
}

// TestRedisRateLimiter 测试分布式限流器
func TestRedisRateLimiter(t *testing.T) {
	ctx := context.Background()
	redisClient := setupRedisClient()

	// 测试Redis连接
	_, err := redisClient.Ping(ctx).Result()
	if err != nil {
		t.Skip("Redis不可用，跳过分布式限流测试")
	}

	// 创建分布式限流器，10秒内最多5个请求
	limiter := limiter.NewRedisRateLimiter(redisClient, "test:ratelimit", 5, 10*time.Second)

	// 清理之前的测试数据
	redisClient.Del(ctx, "test:ratelimit:global")

	// 测试5个请求都能通过
	for i := 0; i < 5; i++ {
		assert.True(t, limiter.Allow(), "应该允许请求通过")
	}

	// 测试第6个请求被拦截
	assert.False(t, limiter.Allow(), "应该拦截请求")

	// 清理测试数据
	redisClient.Del(ctx, "test:ratelimit:global")
}

// TestUserIPLimiter 测试用户和IP限流器
func TestUserIPLimiter(t *testing.T) {
	ctx := context.Background()
	redisClient := setupRedisClient()

	// 测试Redis连接
	_, err := redisClient.Ping(ctx).Result()
	if err != nil {
		t.Skip("Redis不可用，跳过用户IP限流测试")
	}

	// 创建用户限流器，10秒内最多3个请求
	userLimiter := limiter.NewUserRateLimiter(redisClient, 3, 10*time.Second)

	// 清理之前的测试数据
	redisClient.Del(ctx, "ratelimit:user:testuser")

	// 测试3个请求都能通过
	for i := 0; i < 3; i++ {
		assert.True(t, userLimiter.AllowUser("testuser"), "应该允许用户请求通过")
	}

	// 测试第4个请求被拦截
	assert.False(t, userLimiter.AllowUser("testuser"), "应该拦截用户请求")

	// 创建IP限流器，10秒内最多4个请求
	ipLimiter := limiter.NewIPRateLimiter(redisClient, 4, 10*time.Second)

	// 清理之前的测试数据
	redisClient.Del(ctx, "ratelimit:ip:127.0.0.1")

	// 测试4个请求都能通过
	for i := 0; i < 4; i++ {
		assert.True(t, ipLimiter.AllowIP("127.0.0.1"), "应该允许IP请求通过")
	}

	// 测试第5个请求被拦截
	assert.False(t, ipLimiter.AllowIP("127.0.0.1"), "应该拦截IP请求")

	// 清理测试数据
	redisClient.Del(ctx, "ratelimit:user:testuser")
	redisClient.Del(ctx, "ratelimit:ip:127.0.0.1")
}

// TestAdaptiveBreaker 测试自适应熔断器
func TestAdaptiveBreaker(t *testing.T) {
	// 创建自适应熔断器
	adaptiveBreaker := breaker.NewAdaptiveBreaker(
		breaker.WithErrorThreshold(0.5),                  // 50%错误率触发熔断
		breaker.WithMinRequestCount(5),                   // 最少5个请求触发熔断
		breaker.WithRecoveryWindow(500*time.Millisecond), // 500ms后尝试恢复
		breaker.WithRecoveryRate(0.2),                    // 恢复期间允许20%请求通过
	)

	// 重置断路器确保初始状态
	adaptiveBreaker.Reset()

	// 初始状态应为关闭
	assert.Equal(t, breaker.StateClosed, adaptiveBreaker.GetState(), "初始状态应为关闭")

	// 发送请求并触发错误
	for i := 0; i < 10; i++ {
		err := adaptiveBreaker.Execute(func() error {
			if i%2 == 0 {
				return errors.New("模拟错误")
			}
			return nil
		})
		if err != nil {
			t.Logf("请求%d失败: %v", i, err)
		}
	}

	// 此时错误率为50%，应触发熔断
	assert.Equal(t, breaker.StateOpen, adaptiveBreaker.GetState(), "应切换到开启状态")

	// 发送请求，应被熔断器拦截
	err := adaptiveBreaker.Execute(func() error {
		t.Fatalf("熔断状态下不应执行此代码")
		return nil
	})
	assert.Equal(t, breaker.ErrCircuitOpenAdaptive, err, "应返回熔断器开启错误")

	// 等待恢复窗口（使用较短时间）
	time.Sleep(500 * time.Millisecond)

	// 创建带超时的上下文
	ctx, cancel := context.WithTimeout(context.Background(), 1*time.Second)
	defer cancel()

	// 现在应处于半开状态，允许部分请求通过
	var passCount int32 // 使用int32类型以便使用atomic操作
	var wg sync.WaitGroup
	wg.Add(20)

	for i := 0; i < 20; i++ {
		go func(index int) {
			defer wg.Done()

			// 使用ExecuteWithResult避免可能的阻塞
			_, err := adaptiveBreaker.ExecuteWithResult(ctx, "test", func() (interface{}, error) {
				atomic.AddInt32(&passCount, 1)
				return nil, nil
			})
			if err == nil {
				t.Logf("请求%d通过", index)
			}
		}(i)
	}

	// 等待所有请求完成，最多等待1秒
	doneCh := make(chan struct{})
	go func() {
		wg.Wait()
		close(doneCh)
	}()

	select {
	case <-doneCh:
		// 所有请求已完成
	case <-time.After(1 * time.Second):
		t.Log("等待请求完成超时")
	}

	// 验证只有部分请求通过（大约20%）
	t.Logf("半开状态下通过的请求数: %d", passCount)
	assert.True(t, passCount > 0 && passCount <= 5, "半开状态应只允许部分请求通过")

	// 重置熔断器
	adaptiveBreaker.Reset()
	assert.Equal(t, breaker.StateClosed, adaptiveBreaker.GetState(), "重置后状态应为关闭")
}

// TestLimiterMiddleware 测试限流中间件
func TestLimiterMiddleware(t *testing.T) {
	// 创建限流器，每秒2个请求
	rateLimiter := limiter.NewTokenBucket(2, 2)

	// 创建一个简单的处理函数
	handler := http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		w.WriteHeader(http.StatusOK)
		w.Write([]byte("OK"))
	})

	// 使用限流中间件包装处理函数
	middlewareHandler := middleware.RateLimiterMiddleware(rateLimiter)(handler)

	// 创建HTTP请求和记录响应的recorder
	req := httptest.NewRequest("GET", "http://example.com/foo", nil)

	// 前两个请求应该通过
	for i := 0; i < 2; i++ {
		w := httptest.NewRecorder()
		middlewareHandler.ServeHTTP(w, req)
		assert.Equal(t, http.StatusOK, w.Code, "请求应该通过")
	}

	// 第三个请求应该被限流
	w := httptest.NewRecorder()
	middlewareHandler.ServeHTTP(w, req)
	assert.Equal(t, http.StatusTooManyRequests, w.Code, "请求应该被限流")
}

// TestCircuitBreakerMiddleware 测试熔断器中间件
func TestCircuitBreakerMiddleware(t *testing.T) {
	// 创建自适应熔断器
	adaptiveBreaker := breaker.NewAdaptiveBreaker(
		breaker.WithErrorThreshold(0.5),           // 50%错误率触发熔断
		breaker.WithMinRequestCount(5),            // 仅需要5个请求就触发
		breaker.WithRecoveryWindow(1*time.Second), // 1秒后尝试恢复
	)

	// 创建指标收集器和熔断器指标
	redisClient := setupRedisClient()

	// 如果Redis不可用，创建一个空的指标收集器
	var metricsCollector *metrics.MetricsCollector
	if redisClient != nil {
		ctx, cancel := context.WithTimeout(context.Background(), 100*time.Millisecond)
		defer cancel()
		if _, err := redisClient.Ping(ctx).Result(); err == nil {
			metricsCollector = metrics.NewMetricsCollector(redisClient, "test:metrics", 10*time.Second)
		} else {
			t.Log("Redis不可用，跳过指标收集部分")
		}
	} else {
		t.Log("Redis客户端为nil，跳过指标收集部分")
	}

	breakerMetrics := metrics.NewBreakerMetrics(metricsCollector, "test")

	// 创建一个返回错误的处理函数
	handler := http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		if r.URL.Path == "/success" {
			w.WriteHeader(http.StatusOK)
			return
		}
		w.WriteHeader(http.StatusInternalServerError)
	})

	// 使用熔断器中间件包装处理函数，可以直接使用AdaptiveBreaker
	middlewareHandler := middleware.AdaptiveBreakerMiddleware(adaptiveBreaker, "test", breakerMetrics)(handler)

	// 重置熔断器状态
	adaptiveBreaker.Reset()

	// 先发送一些错误请求触发熔断
	for i := 0; i < 10; i++ {
		w := httptest.NewRecorder()
		req := httptest.NewRequest("GET", "http://example.com/error", nil)
		middlewareHandler.ServeHTTP(w, req)
	}

	// 检查熔断器状态
	assert.Equal(t, breaker.StateOpen, adaptiveBreaker.GetState(), "应触发熔断")

	// 此时请求应该被熔断器拦截
	w := httptest.NewRecorder()
	req := httptest.NewRequest("GET", "http://example.com/success", nil)
	middlewareHandler.ServeHTTP(w, req)
	assert.Equal(t, http.StatusServiceUnavailable, w.Code, "请求应该被熔断器拦截")

	// 等待熔断器恢复
	time.Sleep(1 * time.Second)

	// 重置熔断器
	adaptiveBreaker.Reset()

	// 发送成功请求
	w = httptest.NewRecorder()
	req = httptest.NewRequest("GET", "http://example.com/success", nil)
	middlewareHandler.ServeHTTP(w, req)
	assert.Equal(t, http.StatusOK, w.Code, "请求应该成功")
}

// TestPathRateLimiterMiddleware 测试路径级别限流中间件
func TestPathRateLimiterMiddleware(t *testing.T) {
	// 创建不同路径的限流器
	createLimiter := limiter.NewTokenBucket(1, 1) // 每秒1个请求
	listLimiter := limiter.NewTokenBucket(5, 5)   // 每秒5个请求

	pathLimiters := map[string]limiter.RateLimiter{
		"/order/create": createLimiter,
		"/order/list":   listLimiter,
	}

	// 创建一个简单的处理函数
	handler := http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		w.WriteHeader(http.StatusOK)
		w.Write([]byte("OK"))
	})

	// 使用路径限流中间件包装处理函数
	middlewareHandler := middleware.PathRateLimiterMiddleware(pathLimiters)(handler)

	// 测试/order/create路径（每秒1个请求）
	req1 := httptest.NewRequest("GET", "http://example.com/order/create", nil)

	// 第一个请求应该通过
	w := httptest.NewRecorder()
	middlewareHandler.ServeHTTP(w, req1)
	assert.Equal(t, http.StatusOK, w.Code, "第一个创建请求应该通过")

	// 第二个请求应该被限流
	w = httptest.NewRecorder()
	middlewareHandler.ServeHTTP(w, req1)
	assert.Equal(t, http.StatusTooManyRequests, w.Code, "第二个创建请求应该被限流")

	// 测试/order/list路径（每秒5个请求）
	req2 := httptest.NewRequest("GET", "http://example.com/order/list", nil)

	// 前5个请求应该通过
	for i := 0; i < 5; i++ {
		w := httptest.NewRecorder()
		middlewareHandler.ServeHTTP(w, req2)
		assert.Equal(t, http.StatusOK, w.Code, "列表请求应该通过")
	}

	// 第6个请求应该被限流
	w = httptest.NewRecorder()
	middlewareHandler.ServeHTTP(w, req2)
	assert.Equal(t, http.StatusTooManyRequests, w.Code, "第6个列表请求应该被限流")
}

// TestFallbackFunction 测试降级函数
func TestFallbackFunction(t *testing.T) {
	// 创建自适应熔断器
	adaptiveBreaker := breaker.NewAdaptiveBreaker(
		breaker.WithErrorThreshold(0.5),
		breaker.WithMinRequestCount(5), // 减少所需的最小请求数
		breaker.WithRecoveryWindow(1*time.Second),
	)

	// 注册降级函数
	fallbackCalled := false
	adaptiveBreaker.RegisterFallback("testOp", func(err error) (interface{}, error) {
		fallbackCalled = true
		return "降级响应", nil
	})

	// 重置熔断器
	adaptiveBreaker.Reset()

	// 触发熔断
	for i := 0; i < 10; i++ {
		adaptiveBreaker.Execute(func() error {
			return errors.New("模拟错误")
		})
	}

	// 确认熔断器已开启
	assert.Equal(t, breaker.StateOpen, adaptiveBreaker.GetState(), "熔断器应开启")

	// 执行带降级的请求，使用有超时的上下文
	ctx, cancel := context.WithTimeout(context.Background(), 1*time.Second)
	defer cancel()

	result, err := adaptiveBreaker.ExecuteWithResult(ctx, "testOp", func() (interface{}, error) {
		// 断路器处于打开状态时不应执行此函数
		return nil, errors.New("不应执行")
	})

	// 验证降级函数被调用
	assert.True(t, fallbackCalled, "降级函数应被调用")
	assert.Equal(t, "降级响应", result, "应返回降级响应")
	assert.Nil(t, err, "不应返回错误")
}
