# 秒杀系统设计文档

## 1. 系统概述

基于Go语言实现的微服务架构秒杀系统，具备高并发、高可用的特性，专为闪购、秒杀等高流量场景设计。系统通过多层次保护机制确保在瞬时高并发下保持稳定性，并能优雅降级。

## 2. 技术栈

- **开发语言**：Go
- **数据库**：MySQL
- **缓存**：Redis 7.x（集群模式）
- **消息队列**：RabbitMQ（带死信队列）
- **部署环境**：Docker Compose
- **API网关**：Nginx

## 3. 项目结构

```
├── gateway/            # API网关层
├── service/            # 微服务实现
│   ├── inventory/      # 库存服务
│   └── order/          # 订单服务
├── pkg/                # 公共功能包
│   ├── breaker/        # 熔断器实现
│   ├── config/         # 动态配置中心
│   ├── dlock/          # 分布式锁实现
│   ├── errcode/        # 统一错误码
│   ├── httpclient/     # HTTP客户端封装
│   ├── limiter/        # 限流器实现
│   ├── metrics/        # 指标收集
│   └── mq/             # 消息队列封装
├── docker-compose.yml  # Docker部署配置
└── README.md           # 项目文档
```

## 4. 核心服务

### 4.1 库存服务

- **Redis库存预热**：采用Hash结构存储商品库存
- **原子操作**：使用Lua脚本保证库存操作原子性
- **库存补偿**：定时任务同步数据库与缓存，保证数据一致性
- **预扣库存**：支持库存预扣减与释放
- **领域模型**：库存、商品、活动等领域模型设计

### 4.2 订单服务

- **状态机**：完整的订单状态流转系统
- **延迟队列**：RabbitMQ处理超时未支付订单
- **分表策略**：基于用户ID的订单表分片
- **流量削峰**：异步处理订单创建请求
- **idempotent**：实现订单幂等性处理

### 4.3 API网关

- **请求路由**：动态请求路由
- **权限控制**：身份验证与授权
- **流量控制**：IP黑名单与访问频率限制
- **数据过滤**：输入验证与数据清洗
- **请求签名**：防止请求篡改

## 5. 高并发保护机制

### 5.1 多层次限流策略

系统实现了全方位的限流保护：

- **全局限流**：控制整个服务的总体流量
- **路径限流**：针对不同API接口实施差异化限流策略
- **用户限流**：基于用户ID限流，防止单用户大量请求
- **IP限流**：基于来源IP地址限流，防止恶意攻击

限流算法实现：
- **令牌桶算法**：支持突发流量平滑处理
- **分布式限流**：基于Redis的分布式限流，确保集群环境下限流有效性

```go
// 创建不同级别的限流器
globalLimiter := limiter.NewTokenBucket(float64(globalLimit), float64(globalBurst))
userLimiter := limiter.NewUserRateLimiter(redisClient, userLimit, period)
ipLimiter := limiter.NewIPRateLimiter(redisClient, ipLimit, period)

// 应用多层限流中间件
handler = middleware.UserIPLimiterMiddleware(userLimiter, ipLimiter)(handler)
handler = middleware.PathRateLimiterMiddleware(pathLimiters)(handler)
handler = middleware.MetricsLimiterMiddleware(globalLimiter, limiterMetrics)(handler)
```

### 5.2 熔断与服务降级

系统实现了先进的熔断保护：

- **自适应熔断器**：基于错误率和请求量动态调整熔断策略
- **半开状态管理**：支持渐进式恢复，避免恢复期间再次过载
- **服务降级**：熔断触发时提供优雅降级方案
- **负载感知**：结合系统负载状态进行熔断决策

```go
// 创建自适应熔断器
adaptiveBreaker := breaker.NewAdaptiveBreaker(
    breaker.WithErrorThreshold(0.5),      // 50%错误率触发熔断
    breaker.WithRecoveryWindow(30*time.Second), // 熔断30秒后尝试恢复
    breaker.WithRecoveryRate(0.1),        // 恢复期间允许10%请求通过
)

// 注册降级函数
adaptiveBreaker.RegisterFallback("orderCreate", func(err error) (interface{}, error) {
    // 降级逻辑
    return nil, errors.New("系统繁忙，请稍后再试")
})
```

### 5.3 HTTP客户端增强

改进的HTTP客户端实现：

- **超时控制**：细粒度的连接和请求超时控制
- **重试机制**：自动重试与退避策略
- **连接池管理**：高效复用HTTP连接
- **错误处理**：结构化的错误信息与重试决策

```go
// 创建增强的HTTP客户端
client := httpclient.NewHttpClient(
    "http://inventory-service", // 服务地址
    5*time.Second,             // 请求超时时间
    3                          // 最大重试次数
)

// 使用客户端发起请求
response, err := client.Post(ctx, "/inventory/decrement", requestData)
```

### 5.4 流量削峰填谷

通过消息队列实现流量削峰：

- **异步处理**：将秒杀请求异步化，缓解瞬时压力
- **消息队列**：使用RabbitMQ处理订单创建请求
- **消费端控制**：控制消息处理速率，平滑处理峰值请求
- **延迟队列**：处理订单超时和状态变更

```go
// 创建流量削峰器
peakShaver := mq.NewPeakShaver(orderMQ, 20, 50.0) // 20个工作协程，每秒处理50个消息

// 注册订单消息处理
peakShaver.RegisterHandler("orderCreate", func(data []byte) error {
    return orderService.HandleDelayMessage(ctx, data)
})
```

### 5.5 动态配置中心

基于Redis实现的动态配置中心：

- **实时配置更新**：无需重启服务即可更新配置
- **配置监听**：配置变更通知机制
- **默认值**：配置缺失时提供合理默认值
- **分布式同步**：集群环境下配置同步

```go
// 获取动态配置
globalLimit := dynamicConfig.GetInt("limiter.global.rate", 100)

// 监听配置变更
dynamicConfig.AddListener("breaker.error_threshold", func(key string, oldValue, newValue interface{}) {
    // 配置更新处理逻辑
    adaptiveBreaker.Reset()
})
```

### 5.6 指标监控系统

完整的指标收集与监控：

- **熔断器指标**：状态变化、请求成功率、拒绝次数
- **限流器指标**：请求量、通过率、拒绝率
- **性能指标**：响应时间、请求量、错误率
- **Redis存储**：指标数据存储于Redis，支持时间序列查询

```go
// 创建指标收集器
metricsCollector := metrics.NewMetricsCollector(redisClient, "seckill:metrics", 10*time.Second)

// 记录限流器指标
limiterMetrics := metrics.NewLimiterMetrics(metricsCollector, "global")
limiterMetrics.RecordRequest()
limiterMetrics.RecordAllowed()
```

## 6. 实现原理

### 6.1 限流器实现

- **令牌桶算法**：定期向桶中添加令牌，控制请求通过率
- **分布式限流**：使用Redis+Lua脚本实现分布式限流，保证原子性
- **多级限流**：全局、路径、用户、IP多级限流组合使用

### 6.2 熔断器实现

- **状态机模型**：熔断器基于状态机模型（关闭、开启、半开）
- **错误率统计**：使用滑动窗口收集请求成功/失败数据
- **自适应阈值**：根据历史数据和当前负载动态调整熔断阈值
- **渐进式恢复**：半开状态下逐步增加允许通过的请求数

### 6.3 分布式锁实现

- **Redis实现**：基于Redis的分布式锁
- **超时机制**：锁自动过期，防止死锁
- **原子操作**：使用Lua脚本确保获取和释放锁的原子性
- **锁续期**：支持锁自动续期，适用于长时间操作

### 6.4 消息队列使用

- **订单创建**：异步处理订单创建请求
- **延迟队列**：处理订单超时取消
- **死信队列**：处理消费失败的消息
- **消费速率控制**：控制消息处理速度，平滑处理请求

## 7. 发布与部署

### 7.1 部署架构

- **微服务拆分**：库存服务、订单服务独立部署
- **容器化**：Docker容器封装服务
- **编排**：Docker Compose管理服务组件
- **负载均衡**：Nginx实现负载均衡

### 7.2 灰度发布策略

1. **测试环境验证**：完整功能测试和性能测试
2. **小规模部署**：生产环境部署少量实例
3. **流量切分**：逐步增加灰度实例的流量比例
4. **监控反馈**：持续监控系统指标
5. **全量发布**：确认稳定后全量部署

## 8. 最佳实践

1. **配置调优**：
   - 根据实际流量调整限流参数
   - 基于错误率历史数据优化熔断阈值
   - 优化连接池和超时参数

2. **监控告警**：
   - 对关键指标设置告警阈值
   - 监控熔断器状态变化
   - 跟踪限流拒绝率变化

3. **性能测试**：
   - 模拟正常和峰值流量场景
   - 测试各类保护机制触发条件
   - 评估系统极限承载能力

## 9. 测试指南

系统包含丰富的测试用例，从单元测试到集成测试再到性能测试，以确保各个组件和整体系统的稳定性和性能。按照以下顺序执行测试可以全面验证系统功能：

### 9.1 单元测试（基础服务模块测试）

```bash
# 测试HTTP客户端
go test -v ./tests/httpclient/httpclient_test.go

# 测试库存服务
go test -v ./tests/inventory/inventory_service_test.go

# 测试订单服务
go test -v ./tests/order/order_service_test.go

# 测试订单状态机
go test -v ./tests/order/order_state_machine_test.go
```

### 9.2 功能特性测试（限流和熔断）

```bash
# 测试中间件功能
go test -v ./tests/middleware/middleware_test.go

# 测试熔断器恢复功能
go test -v ./tests/middleware/middleware_recovery_test.go

# 测试限流器的边缘情况
go test -v ./tests/limiter/limiter_edge_test.go -run TestTokenBucketEdgeCases
go test -v ./tests/limiter/limiter_edge_test.go -run TestRedisRateLimiterEdgeCases
go test -v ./tests/limiter/limiter_edge_test.go -run TestUserIPRateLimiterEdgeCases
go test -v ./tests/limiter/limiter_edge_test.go -run TestMultiLimiterCombination

# 测试熔断器的边缘情况
go test -v ./tests/breaker/breaker_edge_test.go -run TestAdaptiveBreakerEdgeCases
go test -v ./tests/breaker/breaker_edge_test.go -run TestAdaptiveBreakerRecovery
go test -v ./tests/breaker/breaker_edge_test.go -run TestBreakerFallback
```

### 9.3 集成测试（整体系统测试）

```bash
# 测试抢购流程（需要先确保相关服务和数据库已准备就绪）
go test -v ./tests/integration/seckill_test.go -run TestFullSeckillProcess

# 测试订单超时
go test -v ./tests/integration/seckill_test.go -run TestOrderTimeout

# 测试并发抢购
go test -v ./tests/integration/seckill_test.go -run TestConcurrentSeckill

# 测试熔断器和限流器在实际场景中的应用
go test -v ./tests/integration/seckill_test.go -run TestCircuitBreaker
go test -v ./tests/integration/seckill_test.go -run TestRateLimiter
```

### 9.4 性能基准测试

```bash
# 限流器性能测试
go test -bench=BenchmarkTokenBucket ./tests/bench/middleware_benchmark_test.go
go test -bench=BenchmarkRedisRateLimiter ./tests/bench/middleware_benchmark_test.go
go test -bench=BenchmarkUserIPRateLimiter ./tests/bench/middleware_benchmark_test.go

# 熔断器性能测试
go test -bench=BenchmarkAdaptiveBreaker ./tests/bench/middleware_benchmark_test.go

# 抢购系统整体性能测试
go test -bench=. ./tests/bench/seckill_benchmark_test.go
```

### 9.5 全套测试（一次运行所有测试）

```bash
# 运行所有单元测试
go test -v ./tests/...

# 运行所有中间件测试
go test -v ./tests/middleware/...

# 运行所有限流器测试
go test -v ./tests/limiter/...

# 运行所有熔断器测试
go test -v ./tests/breaker/...

# 运行所有集成测试
go test -v ./tests/integration/...

# 运行所有基准测试
go test -bench=. ./tests/bench/...
```

### 9.6 测试注意事项

1. **环境准备**：
   - 集成测试需要确保Redis、MySQL、RabbitMQ服务已正确配置并启动
   - 确保测试数据库已初始化（`make init-testdb`）
   - 测试前可能需要预置一些测试数据

2. **模拟模式测试**：
   - 部分单元测试支持在没有外部依赖的情况下运行，自动切换到模拟模式
   - 库存服务测试会在无法连接MySQL或Redis时自动使用模拟实现
   - 运行带有数据库依赖的测试前，请先确保数据库可用，或使用`-run TestMock`参数仅运行模拟测试
   - 示例：`go test -v ./tests/inventory/inventory_service_test.go -run TestMockInventory`

3. **依赖处理**：
   - 有些测试可能依赖特定环境变量或配置文件
   - 确保已安装所有依赖包（`go mod tidy`）

4. **性能测试建议**：
   - 使用`-benchtime`参数调整运行时间，例如：`-benchtime=10s`
   - 使用`-benchmem`查看内存分配情况
   - 在与生产环境相似的机器上运行性能测试，以获得更准确的结果

5. **调试失败的测试**：
   - 使用`-v`参数查看详细输出
   - 使用`-run=TestName/SubtestName`执行特定的测试
   - 查看测试日志文件获取更多信息

## 10. 后续优化方向

1. **完善可观测性**：接入Grafana等可视化工具
2. **智能限流**：基于机器学习的自适应限流
3. **弹性伸缩**：根据流量自动扩展服务实例
4. **链路追踪**：接入Jaeger实现分布式追踪
5. **分库分表**：进一步优化数据库性能
6. **容量规划**：基于历史数据进行资源优化