package com.mooc.jiangzh.dubbo.springboot.springbootdubbo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringbootDubboApplication {

    public static void main(String[] args) {
        SpringApplication.run(SpringbootDubboApplication.class, args);
    }
}
