package com.geekq.dubbo.springboot.privoder.config;

import org.springframework.context.annotation.Configuration;

@Configuration
public class TCCConfig {
}
