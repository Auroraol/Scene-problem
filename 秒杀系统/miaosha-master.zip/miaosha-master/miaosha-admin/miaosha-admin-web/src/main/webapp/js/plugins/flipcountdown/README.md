flipCountDown
==============
[Demo&Documentation][doc]


jQuery Plugin Flip Count Down Retro Clock

flipCountDown

![ScreenShot](/screen/1.png)

![ScreenShot](/screen/2.png)

[doc]: http://xdsoft.net/jqplugins/flipcountdown/
