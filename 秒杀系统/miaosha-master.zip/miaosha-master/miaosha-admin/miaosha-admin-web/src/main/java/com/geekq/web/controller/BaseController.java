package com.geekq.web.controller;

/**
 * @author 邱润泽
 */
abstract public class BaseController {
}
