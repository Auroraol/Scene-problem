package com.geekq.web.service;

public interface CulsterService {

    /**
     * @Description: 购买商品
     */
    public void doBuyItem(String itemId);

    public boolean displayBuy(String itemId);
}

