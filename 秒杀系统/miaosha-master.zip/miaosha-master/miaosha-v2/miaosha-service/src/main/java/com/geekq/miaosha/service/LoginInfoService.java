package com.geekq.miaosha.service;

/**
 * @author 邱润泽
 */
public interface LoginInfoService {

    public String checkName();
}
