package com.geekq.miasha.entity;

import lombok.Getter;
import lombok.Setter;

import java.io.Serializable;

/**
 * @author qiurunze
 */
@Getter
@Setter
public class BaseDomain implements Serializable {

    protected Long id;

}
