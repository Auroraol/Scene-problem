### dubbo-admin 平台搭建与管理

    有问题或者宝贵意见联系我的QQ,非常希望你的加入！
    
#### [dubbo-admin-2.6.0 war包 请进入/docs/dubbo-admin/下载](/docs/dubbo-admin/dubbo-admin-2.6.0.war)

1.可直接 https://github.com/apache/incubator-dubbo/releases/tag/dubbo-2.6.0 下载后将dubbo-admin-2.6.0达成war包

2./docs/dubbo-admin/dubbo-admin-2.6.0.war获取war包 

3.获取后 将war包放在tomcat的webapp目录 

4.启动 window startup.bat linux ./bin/startup.sh 启动 -- 记得安装zk客户端才可以启动成功

5.访问 http://端口号:8080/dubbo-admin-2.6.0/  可成功

6.账号密码 root/root