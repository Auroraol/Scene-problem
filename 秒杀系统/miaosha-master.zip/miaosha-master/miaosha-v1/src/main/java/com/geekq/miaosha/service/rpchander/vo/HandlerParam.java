package com.geekq.miaosha.service.rpchander.vo;

public class HandlerParam {

    private int realCount;
    private PlanOrder planOrder;
    private PlanStep planStep;

}
