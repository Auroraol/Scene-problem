package com.geekq.miaosha.service.rpchander.enums;

public enum PlanStepStatus {

    INIT, //未处理
    PROCESSING,//处理中
    SUCCESS, //成功
    FAIL, //失败
    ROLLED_BACK, //已回滚

}
